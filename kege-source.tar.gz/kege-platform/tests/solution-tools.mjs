import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import ts from 'typescript';
async function module(name){const source=await readFile(new URL(`../src/lib/${name}.ts`,import.meta.url),'utf8');const scope={exports:{}};vm.runInNewContext(ts.transpile(source.replace(/^import .*;\n/,''),{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}),scope);return scope.exports;}
const {attachedTaskIds}=await module('solutionStats');
const base={task_id:'one',student_id:'pupil',code:'print(1)',image:''};
const works=[base,{...base,code:'print(2)'},{...base,task_id:'two',code:'',image:'data:image/jpeg;base64,AA=='},{...base,task_id:'empty',code:' \n'},{...base,student_id:'other',task_id:'private'},{...base,task_id:null}];
assert.deepEqual([...attachedTaskIds(works,'pupil')].sort(),['one','two']);
assert.equal(attachedTaskIds(works,'nobody').size,0);
const {solutionFileKind:kind}=await module('solutionFile');
assert.equal(kind({name:'screenshot.png',type:'image/png',size:100}),'image');
assert.equal(kind({name:'answer.PY',type:'',size:100}),'code');
assert.equal(kind({name:'answer.txt',type:'text/plain',size:100}),'code');
assert.throws(()=>kind({name:'x.exe',type:'application/octet-stream',size:100}));
assert.throws(()=>kind({name:'x.py',type:'',size:100001}));
assert.throws(()=>kind({name:'x.png',type:'image/png',size:10000001}));
console.log('PASS: unique own attached solutions and supported solution file limits.');
