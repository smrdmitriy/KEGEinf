import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import ts from 'typescript';
import { webcrypto } from 'node:crypto';
const source = (await readFile(new URL('../supabase/functions/create-student/index.ts', import.meta.url), 'utf8')).replace(/^import .*;\n/, '');
const script = ts.transpile(source, { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None });
let handler, role = 'teacher', invalidToken = false, invalidGroup = false, failEnrollment = false, duplicate = false;
let created = [], deleted = [], enrolled = [];
const admin = {
 auth: { getUser: async () => ({ data: { user: invalidToken ? null : { id: 'teacher-id' } }, error: invalidToken }), admin: {
  createUser: async (input) => { created.push(input); return { data: { user: duplicate ? null : { id: 'new-student' } }, error: duplicate }; },
  deleteUser: async (id) => { deleted.push(id); return { error: null }; },
 } },
 from: table => { const q = { select: () => q, eq: () => q, single: async () => ({ data: { role } }), maybeSingle: async () => ({ data: invalidGroup ? null : { id: 'group' } }) }; return q; },
 rpc: async (name, args) => { enrolled.push({ name, args }); return { error: failEnrollment }; },
};
vm.runInNewContext(script, { createClient: () => admin, Deno: { env: { get: () => 'configured' }, serve: fn => { handler = fn; } }, Response, Request, crypto: webcrypto, Uint8Array });
const request = (body = { name: 'Анна', email: 'Anna@example.ru' }, token = 'valid') => handler(new Request('https://test/create-student', { method: 'POST', headers: token ? { Authorization: `Bearer ${token}` } : {}, body: JSON.stringify(body) }));
assert.equal((await request(undefined, '')).status, 401);
invalidToken = true; assert.equal((await request()).status, 401); invalidToken = false;
role = 'student'; assert.equal((await request()).status, 403); role = 'teacher';
assert.equal(created.length, 0, 'Unauthorized callers cannot create Auth users');
assert.equal((await request({ name: '', email: 'bad' })).status, 400);
invalidGroup = true; assert.equal((await request({ name: 'A', email: 'a@example.ru', group_id: '30000000-0000-4000-8000-000000000001' })).status, 403); invalidGroup = false;
const response = await request({ name: 'Анна', email: 'Anna@example.ru', teacher_id: 'attacker', role: 'teacher' });
assert.equal(response.status, 201); assert.equal(response.headers.get('cache-control'), 'no-store');
const result = await response.json(); assert.equal(result.email, 'anna@example.ru'); assert.equal(result.password.length, 39);
assert.equal(created[0].password, result.password); assert.equal(created[0].user_metadata.role, undefined);
assert.equal(enrolled[0].args.teacher, 'teacher-id', 'Teacher comes from verified Auth, never request');
const second = await (await request()).json(); assert.notEqual(second.password, result.password);
failEnrollment = true; assert.equal((await request()).status, 500); assert.equal(deleted.length, 1); failEnrollment = false;
duplicate = true; const failed = await request(); assert.equal(failed.status, 409); assert.equal((await failed.json()).password, undefined);
console.log('PASS: Edge handler auth, role checks, group validation, server-bound ownership, random passwords, duplicate rejection, compensation and no-store.');
