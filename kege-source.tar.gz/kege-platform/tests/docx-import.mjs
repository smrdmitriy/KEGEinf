import ts from 'typescript';
import {readFile,writeFile,unlink} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {DOMParser} from '@xmldom/xmldom';
import {unzipSync,zipSync,strFromU8,strToU8} from 'fflate';
globalThis.DOMParser=DOMParser;
const path=new URL('../src/lib/.docx-import-test.mjs',import.meta.url);
await writeFile(path,ts.transpileModule(await readFile(new URL('../src/lib/docxImport.ts',import.meta.url),'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText);
try {
 const {readDocx,docxTemplate,parseTaskText}=await import(path.href);
 const sample=docxTemplate(5);const parsed=readDocx(sample,1);
 assert.equal(parsed.length,2);assert.equal(parsed[0].module,5);assert.equal(parsed[1].answer,'42');
 const files=unzipSync(sample);const original=strFromU8(files['word/document.xml']);
 function altered(xml){return zipSync({...files,'word/document.xml':strToU8(xml)});}
 assert.equal(readDocx(altered(original.replace('Ответ: 42','От</w:t></w:r><w:r><w:t>вет: 42')),1)[0].answer,'42','Formatting splits must preserve labels');
 assert.throws(()=>readDocx(new Uint8Array([1,2,3]),5));
 assert.throws(()=>readDocx(new Uint8Array(4000001),5));
 assert.throws(()=>readDocx(altered(original.replace('<w:body>','<w:body><w:tbl/>')),5),/Таблицы/);
 assert.throws(()=>readDocx(altered(original.replace('<w:body>','<w:body><w:drawing/>')),5),/Таблицы/);
 const text='Задача 1\nНазвание: Тест\nУсловие: Первая строка\nВторая строка\nОтвет: 001\nРешение:\nfor i in range(3):\n    print(i)';
 const one=parseTaskText(text,27)[0];assert.equal(one.module,27);assert.equal(one.answer,'001');assert.ok(one.statement.includes('\n'));assert.ok(one.solution.includes('    print(i)'));
 assert.throws(()=>parseTaskText(text.replace('Ответ: 001','Ответ:'),5),/Ответ/);
 assert.throws(()=>parseTaskText(text+'\nОтвет: 2',5),/повторяется/);
 assert.throws(()=>parseTaskText(text.replace('Название:', 'Номер: 28\nНазвание:'),5),/от 1 до 27/);
 assert.throws(()=>parseTaskText(Array.from({length:201},()=>text).join('\n'),5),/200/);
 assert.throws(()=>parseTaskText('Нет разметки',5),/не найдены/);
 console.log('PASS: DOCX template round-trip, split Word runs, multiline code, exact answers, limits, malformed files and unsupported content.');
}finally{await unlink(path);}
