import { createClient } from 'npm:@supabase/supabase-js@2.119.0';

const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
  'Cache-Control': 'no-store',
};
const reply = (status: number, body: object) => new Response(JSON.stringify(body), { status, headers });

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers });
  if (req.method !== 'POST') return reply(405, { error: 'Метод не поддерживается' });
  const url = Deno.env.get('SUPABASE_URL');
  const key = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !key) return reply(503, { error: 'Сервис создания кабинетов не настроен' });
  const admin = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  const token = req.headers.get('Authorization')?.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) return reply(401, { error: 'Войдите в учётную запись преподавателя' });
  // Verify the token with Auth; never trust a role or teacher ID from request metadata.
  const { data: auth, error: authError } = await admin.auth.getUser(token);
  if (authError || !auth.user) return reply(401, { error: 'Сессия истекла. Войдите снова' });
  const { data: teacher, error: roleError } = await admin.from('profiles').select('role').eq('id', auth.user.id).single();
  if (roleError || teacher?.role !== 'teacher') return reply(403, { error: 'Только преподаватель может создавать кабинеты' });
  let body;
  try { const text = await req.text(); if (text.length > 4096) return reply(413, { error: 'Слишком большой запрос' }); body = JSON.parse(text); }
  catch { return reply(400, { error: 'Некорректный запрос' }); }
  const name = typeof body?.name === 'string' ? body.name.trim() : '';
  const email = typeof body?.email === 'string' ? body.email.trim().toLowerCase() : '';
  const group = body?.group_id || null;
  if (!name || name.length > 80 || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return reply(400, { error: 'Укажите имя (до 80 символов) и корректную почту' });
  if (group) {
    if (typeof group !== 'string' || !/^[0-9a-f-]{36}$/i.test(group)) return reply(400, { error: 'Некорректная группа' });
    const { data, error } = await admin.from('groups').select('id').eq('id', group).eq('teacher_id', auth.user.id).maybeSingle();
    if (error || !data) return reply(403, { error: 'Группа недоступна' });
  }
  // 144 random bits, no Math.random; no passwords in logs, tables or browser storage.
  const bytes = crypto.getRandomValues(new Uint8Array(18));
  const password = 'K9!' + Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
  const { data: created, error: createError } = await admin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { name } });
  if (createError || !created.user) return reply(409, { error: 'Не удалось создать кабинет. Возможно, эта почта уже используется. Обратитесь к администратору, если нужен возврат доступа.' });
  const { error: enrollmentError } = await admin.rpc('complete_student_enrollment', { student: created.user.id, teacher: auth.user.id, selected_group: group });
  if (enrollmentError) {
    // Compensate the Auth operation if enrollment failed; an orphan has no RLS access either way.
    await admin.auth.admin.deleteUser(created.user.id);
    return reply(500, { error: 'Не удалось выдать доступ. Обратитесь к администратору.' });
  }
  return reply(201, { email, password });
});
