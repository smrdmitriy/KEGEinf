# Подключённый проект

- Supabase project ref: `zdxtlgzagdewbnftzyix`
- Регион: Frankfurt (eu-central-1)
- Сайт: https://smrdmitriy.github.io/KEGEinf/
- Схема миграций 001 + 002 применена через SQL Editor одним объединённым SQL-скриптом. История CLI migrations не заполнялась; не запускайте 001/002 повторно на этом проекте.
- Функция `create-student` опубликована через Dashboard. Проверка JWT выполняется внутри обработчика через `auth.getUser(token)`; legacy gateway verification отключена.
- Публичная регистрация отключена, Email/Password включён, Site URL настроен.
- GitHub Actions Variables: VITE_SUPABASE_URL и VITE_SUPABASE_ANON_KEY (публичный publishable key).
- Проверено: вызов функции без сессии возвращает 401; чтение profiles/attempts/tasks публичным ключом запрещено; Auth settings сообщает disable_signup=true.
- Требуется закончить создание первого преподавателя и проверить полный сценарий входа/добавления ученика.

Не храните пароли и service_role в этом файле или репозитории.
