begin;
create function public.revoke_study_block(selected_block uuid,selected_student uuid default null,school_class text default null,selected_group uuid default null,all_students boolean default false) returns integer language plpgsql security definer set search_path='' as $$
declare total integer;
begin
 if not private.is_teacher() or not exists(select 1 from public.task_folders where id=selected_block and teacher_id=auth.uid()) then raise exception 'Блок недоступен';end if;
 if all_students is null or (all_students and num_nonnulls(selected_student,nullif(trim(school_class),''),selected_group)<>0) or (not all_students and num_nonnulls(selected_student,nullif(trim(school_class),''),selected_group)<>1) then raise exception 'Выберите одного получателя или всех учеников';end if;
 if selected_student is not null and not exists(select 1 from public.enrollments where student_id=selected_student and teacher_id=auth.uid()) then raise exception 'Ученик недоступен';end if;
 if selected_group is not null and not exists(select 1 from public.groups where id=selected_group and teacher_id=auth.uid()) then raise exception 'Группа недоступна';end if;
 delete from public.study_block_members m using public.enrollments e,public.profiles p
 where m.block_id=selected_block and e.student_id=m.student_id and e.teacher_id=auth.uid() and p.id=e.student_id and (all_students or e.student_id=selected_student or p.school_class=nullif(trim(revoke_study_block.school_class),'') or e.group_id=selected_group);
 get diagnostics total=row_count;return total;
end;$$;
revoke all on function public.revoke_study_block(uuid,uuid,text,uuid,boolean) from public,anon;
grant execute on function public.revoke_study_block(uuid,uuid,text,uuid,boolean) to authenticated;
commit;
