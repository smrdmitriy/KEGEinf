begin;
-- Keep existing content while restoring the standard numbered bank.
do $$ declare block public.task_folders; saved uuid;
begin
 for block in select * from public.task_folders where module between 2 and 27 and module<>5 and name='Задание №'||module and work_type='classwork' loop
  if block.theory<>'' or exists(select 1 from public.tasks where folder_id=block.id) then
   insert into public.task_folders(teacher_id,module,work_type,name,theory) values(block.teacher_id,null,'classwork','Сохранённые материалы · №'||block.module,block.theory) returning id into saved;
   update public.tasks set folder_id=saved where folder_id=block.id;
   insert into public.study_block_members(block_id,student_id) select saved,student_id from public.study_block_members where block_id=block.id on conflict do nothing;
   update public.task_folders set theory='' where id=block.id;
  end if;
 end loop;
end $$;
insert into public.task_folders(teacher_id,module,work_type,name)
 select p.id,n,'classwork','Задание №'||n from public.profiles p cross join generate_series(1,27) n where p.role='teacher'
 on conflict(teacher_id,module,work_type,name) do nothing;
create function public.ensure_standard_blocks() returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.is_teacher() then raise exception 'Нет доступа';end if;
 insert into public.task_folders(teacher_id,module,work_type,name)
 select auth.uid(),n,'classwork','Задание №'||n from generate_series(1,27) n
 on conflict(teacher_id,module,work_type,name) do nothing;
end;$$;
revoke all on function public.ensure_standard_blocks() from public,anon;
grant execute on function public.ensure_standard_blocks() to authenticated;
commit;
