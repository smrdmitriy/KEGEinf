begin;
alter table public.task_folders alter column module drop not null;
alter table public.task_folders add column theory text not null default '' check(length(theory)<=100000);
create table public.study_block_members (
 block_id uuid not null references public.task_folders(id) on delete cascade,
 student_id uuid not null references public.profiles(id) on delete cascade,
 primary key(block_id,student_id)
);
alter table public.study_block_members enable row level security;
revoke all on public.study_block_members from public,anon,authenticated;
grant select on public.study_block_members to authenticated;
create function private.can_open_study_block(block uuid) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.task_folders f where f.id=block and ((private.is_teacher() and f.teacher_id=auth.uid()) or (private.is_student() and exists(select 1 from public.study_block_members m join public.enrollments e on e.student_id=m.student_id and e.teacher_id=f.teacher_id where m.block_id=f.id and m.student_id=auth.uid()))));
$$;
revoke all on function private.can_open_study_block(uuid) from public,anon;
grant execute on function private.can_open_study_block(uuid) to authenticated;
drop policy folders_read on public.task_folders;
create policy folders_read on public.task_folders for select to authenticated using((private.is_teacher() and teacher_id=auth.uid()) or private.can_open_study_block(id));
grant update(name,theory) on public.task_folders to authenticated;
create policy folders_update on public.task_folders for update to authenticated using(private.is_teacher() and teacher_id=auth.uid()) with check(private.is_teacher() and teacher_id=auth.uid());
create policy members_read on public.study_block_members for select to authenticated using(private.can_open_study_block(block_id));
-- Preserve existing number banks and their access when moving to standalone blocks.
insert into public.task_folders(teacher_id,module,work_type,name)
 select distinct teacher_id,module,'classwork','Задание №'||module from public.tasks where teacher_id is not null and folder_id is null
 on conflict do nothing;
update public.tasks t set folder_id=f.id from public.task_folders f where t.folder_id is null and t.teacher_id=f.teacher_id and t.module=f.module and f.name='Задание №'||t.module and f.work_type='classwork';
insert into public.study_block_members(block_id,student_id)
 select distinct f.id,e.student_id from public.task_folders f join public.enrollments e on e.teacher_id=f.teacher_id where exists(select 1 from public.learning_blocks b where b.student_id=e.student_id and b.teacher_id=e.teacher_id and b.module=f.module) or exists(select 1 from public.homework_blocks b where b.student_id=e.student_id and b.teacher_id=e.teacher_id and b.module=f.module)
 on conflict do nothing;
create function public.assign_study_block(selected_block uuid,selected_student uuid default null,school_class text default null,selected_group uuid default null) returns integer language plpgsql security definer set search_path='' as $$
declare total integer;
begin
 if not private.is_teacher() or not exists(select 1 from public.task_folders where id=selected_block and teacher_id=auth.uid()) then raise exception 'Блок недоступен';end if;
 if num_nonnulls(selected_student,nullif(trim(school_class),''),selected_group)<>1 then raise exception 'Выберите одного получателя';end if;
 insert into public.study_block_members(block_id,student_id)
 select selected_block,e.student_id from public.enrollments e join public.profiles p on p.id=e.student_id where e.teacher_id=auth.uid() and (e.student_id=selected_student or p.school_class=nullif(trim(assign_study_block.school_class),'') or e.group_id=selected_group)
 on conflict do nothing;
 get diagnostics total=row_count;return total;
end;$$;
create or replace function public.save_task(task_data jsonb) returns void language plpgsql security definer set search_path='' as $$
declare destination public.task_folders; selected_folder uuid;
begin
 if not private.is_teacher() then raise exception 'Нет доступа';end if;
 if task_data ? 'folder_id' then selected_folder:=nullif(task_data->>'folder_id','')::uuid;
 else select folder_id into selected_folder from public.tasks where id=(task_data->>'id')::uuid and teacher_id=auth.uid();end if;
 if selected_folder is not null then
 select * into destination from public.task_folders where id=selected_folder and teacher_id=auth.uid();
 if destination.id is null then raise exception 'Блок недоступен';end if;
 end if;
 perform public.save_task_without_folder(task_data);
 update public.tasks set folder_id=selected_folder where id=(task_data->>'id')::uuid and teacher_id=auth.uid();
end;$$;
create or replace function private.can_read_task(task uuid) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.tasks t where t.id=task and ((private.is_teacher() and (t.teacher_id=auth.uid() or (t.teacher_id is null and t.published))) or (private.is_student() and t.published and t.teacher_id=private.own_teacher() and ((t.folder_id is not null and private.can_open_study_block(t.folder_id)) or (t.folder_id is null and ((t.work_type='classwork' and private.block_open(auth.uid(),t.module)) or (t.work_type='homework' and private.homework_open(auth.uid(),t.module))))))));
$$;
-- A block no longer determines the task's exam number or work type.
create or replace function public.move_task(selected_task uuid,selected_folder uuid,selected_module integer,selected_work_type text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.is_teacher() or not exists(select 1 from public.task_folders where id=selected_folder and teacher_id=auth.uid()) then raise exception 'Блок недоступен';end if;
 update public.tasks set folder_id=selected_folder,work_type=selected_work_type where id=selected_task and teacher_id=auth.uid();
 if not found then raise exception 'Задача недоступна';end if;
end;$$;
revoke all on function public.assign_study_block(uuid,uuid,text,uuid) from public,anon;
grant execute on function public.assign_study_block(uuid,uuid,text,uuid) to authenticated;
commit;
