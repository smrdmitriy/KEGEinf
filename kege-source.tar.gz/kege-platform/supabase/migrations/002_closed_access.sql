-- Apply after 001. No browser client may provision accounts or enroll users.
begin;
drop function public.enroll_student(text,uuid);
create or replace function private.is_student() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.profiles p join public.enrollments e on e.student_id=p.id
 join public.profiles t on t.id=e.teacher_id and t.role='teacher'
 where p.id=auth.uid() and p.role='student');
$$;
create or replace function private.can_read_task(task uuid) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.tasks where id=task and
 ((private.is_teacher() and (teacher_id=auth.uid() or (teacher_id is null and published)))
 or (private.is_student() and published and (teacher_id is null or teacher_id=private.own_teacher()))));
$$;
-- Restrictive policies also cover future permissive policies on these tables.
create function private.has_access() returns boolean language sql stable security definer set search_path='' as $$
 select private.is_teacher() or private.is_student();
$$;
revoke all on function private.has_access() from public,anon;
grant execute on function private.has_access() to authenticated;
create policy closed_profiles on public.profiles as restrictive to authenticated using(private.has_access()) with check(private.has_access());
create policy closed_groups on public.groups as restrictive to authenticated using(private.has_access()) with check(private.has_access());
create policy closed_tasks on public.tasks as restrictive to authenticated using(private.has_access()) with check(private.has_access());
create policy closed_attempts on public.attempts as restrictive to authenticated using(private.has_access()) with check(private.has_access());
create policy closed_slides on public.slides as restrictive to authenticated using(private.has_access()) with check(private.has_access());
create policy closed_assignments on public.assignments as restrictive to authenticated using(private.has_access()) with check(private.has_access());
create policy closed_enrollments on public.enrollments as restrictive to authenticated using(private.has_access()) with check(private.has_access());

create function public.complete_student_enrollment(student uuid, teacher uuid, selected_group uuid default null)
returns void language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from public.profiles where id=teacher and role='teacher') then raise exception 'Преподаватель недоступен'; end if;
 if not exists(select 1 from public.profiles where id=student and role='student') then raise exception 'Ученик недоступен'; end if;
 if selected_group is not null and not exists(select 1 from public.groups where id=selected_group and teacher_id=teacher) then raise exception 'Группа недоступна'; end if;
 insert into public.enrollments(student_id,teacher_id,group_id) values(student,teacher,selected_group);
end;
$$;
revoke all on function public.complete_student_enrollment(uuid,uuid,uuid) from public,anon,authenticated;
grant execute on function public.complete_student_enrollment(uuid,uuid,uuid) to service_role;
-- Explicit grants for admin API on projects with customized default privileges.
grant usage on schema public to service_role;
grant select on public.profiles,public.groups to service_role;
commit;
