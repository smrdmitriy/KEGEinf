begin;
create table public.homework_blocks (
 student_id uuid not null references public.profiles(id) on delete cascade,
 teacher_id uuid not null references public.profiles(id),
 module integer not null check(module between 1 and 27), due_date date,
 primary key(student_id,module)
);
alter table public.homework_blocks enable row level security;
revoke all on public.homework_blocks from public,anon,authenticated;
grant select on public.homework_blocks to authenticated;
create policy homework_blocks_read on public.homework_blocks for select to authenticated using(private.has_access() and ((student_id=auth.uid() and teacher_id=private.own_teacher()) or (teacher_id=auth.uid() and private.owns_student(student_id))));
create function private.homework_open(student uuid, block integer) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.homework_blocks h join public.enrollments e on e.student_id=h.student_id and e.teacher_id=h.teacher_id where h.student_id=student and h.module=block)
 and (not exists(select 1 from public.learning_blocks b join public.enrollments e on e.student_id=b.student_id and e.teacher_id=b.teacher_id where b.student_id=student and b.module=block) or private.block_open(student,block));
$$;
create function public.assign_homework_block(selected_module integer, selected_student uuid default null, selected_group uuid default null, deadline date default null) returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.is_teacher() or selected_module is null or selected_module not between 1 and 27 or (selected_student is null)=(selected_group is null) then raise exception 'Неверное назначение';end if;
 if selected_student is not null and not private.owns_student(selected_student) then raise exception 'Ученик недоступен';end if;
 if selected_group is not null and not exists(select 1 from public.groups where id=selected_group and teacher_id=auth.uid()) then raise exception 'Группа недоступна';end if;
 insert into public.homework_blocks(student_id,teacher_id,module,due_date)
 select student_id,auth.uid(),selected_module,deadline from public.enrollments where teacher_id=auth.uid() and (student_id=selected_student or group_id=selected_group)
 on conflict(student_id,module) do update set teacher_id=excluded.teacher_id,due_date=excluded.due_date;
end;$$;
create function public.revoke_homework_block(student uuid, block integer) returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.owns_student(student) then raise exception 'Нет доступа';end if;
 delete from public.homework_blocks where student_id=student and module=block and teacher_id=auth.uid();
end;$$;
create or replace function private.can_read_task(task uuid) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.tasks t where t.id=task and
 ((private.is_teacher() and (t.teacher_id=auth.uid() or (t.teacher_id is null and t.published)))
 or (private.is_student() and t.published and t.teacher_id=private.own_teacher() and (private.block_open(auth.uid(),t.module) or private.homework_open(auth.uid(),t.module)))));
$$;
create or replace function public.send_homework(selected_module integer, task_text text, solution_code text default '', solution_image text default '') returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.is_student() or not private.homework_open(auth.uid(),selected_module) then raise exception 'Домашнее задание не назначено или блок ещё закрыт';end if;
 insert into public.homework(student_id,module,statement,code,image) values(auth.uid(),selected_module,trim(task_text),coalesce(solution_code,''),coalesce(solution_image,''));
end;$$;
revoke all on function private.homework_open(uuid,integer) from public,anon,authenticated;
revoke all on function public.assign_homework_block(integer,uuid,uuid,date),public.revoke_homework_block(uuid,integer) from public,anon,authenticated;
grant execute on function public.assign_homework_block(integer,uuid,uuid,date),public.revoke_homework_block(uuid,integer) to authenticated;
commit;
