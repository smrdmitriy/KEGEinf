begin;
-- Superuser is an additional protected permission; the account keeps its teacher role.
create table private.superusers(user_id uuid primary key references public.profiles(id) on delete cascade, created_at timestamptz not null default now());
create table private.role_audit(id bigint generated always as identity primary key, actor uuid not null, target uuid not null, action text not null, created_at timestamptz not null default now());
alter table private.superusers enable row level security;
alter table private.role_audit enable row level security;
revoke all on private.superusers,private.role_audit from public,anon,authenticated;
create function public.is_superuser() returns boolean language sql stable security definer set search_path='' as $$
 select private.is_teacher() and exists(select 1 from private.superusers where user_id=auth.uid());
$$;
create function public.list_teachers() returns table(id uuid,name text,email text,superuser boolean) language plpgsql stable security definer set search_path='' as $$
begin
 if not public.is_superuser() then raise exception 'Только суперпользователь может управлять преподавателями';end if;
 return query select p.id,p.name,p.email,exists(select 1 from private.superusers s where s.user_id=p.id) from public.profiles p where p.role='teacher' order by p.name;
end;$$;
create function public.grant_teacher(account_email text) returns void language plpgsql security definer set search_path='' as $$
declare target public.profiles;
begin
 if not public.is_superuser() then raise exception 'Только суперпользователь может назначать преподавателей';end if;
 if account_email is null or length(trim(account_email)) not between 3 and 254 then raise exception 'Укажите почту учётной записи';end if;
 select * into target from public.profiles where lower(email)=lower(trim(account_email)) for update;
 if target.id is null then raise exception 'Аккаунт не найден. Сначала создайте его в Supabase Authentication → Users';end if;
 if target.role='teacher' then return;end if;
 if exists(select 1 from public.enrollments where student_id=target.id) then raise exception 'Аккаунт является учеником. Сначала его преподаватель должен закрыть ученический доступ';end if;
 update public.profiles set role='teacher' where id=target.id;
 insert into private.role_audit(actor,target,action) values(auth.uid(),target.id,'grant_teacher');
end;$$;
revoke all on function public.is_superuser(),public.list_teachers(),public.grant_teacher(text) from public,anon,authenticated;
grant execute on function public.is_superuser(),public.list_teachers(),public.grant_teacher(text) to authenticated;
commit;
-- Initial superuser assignment is a separate administrator action, never an email-based runtime bypass.
