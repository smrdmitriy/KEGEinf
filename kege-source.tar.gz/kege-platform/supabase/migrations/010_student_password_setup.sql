begin;
-- Admin API still needs SQL privileges even though its role bypasses RLS.
grant select on public.enrollments to service_role;
alter table public.profiles add column must_change_password boolean not null default true;
-- Auth owns the password. Only a real Auth password update clears this flag.
create function private.track_student_password() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if new.encrypted_password is distinct from old.encrypted_password then
  update public.profiles set must_change_password =
   (new.raw_app_meta_data->>'password_reset_nonce' is distinct from old.raw_app_meta_data->>'password_reset_nonce')
  where id=new.id and role='student';
 end if;
 return new;
end; $$;
revoke all on function private.track_student_password() from public,anon,authenticated;
create trigger track_student_password after update on auth.users for each row execute function private.track_student_password();
create function private.password_ready() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.profiles where id=auth.uid() and (role='teacher' or not must_change_password));
$$;
revoke all on function private.password_ready() from public,anon;
grant execute on function private.password_ready() to authenticated;
-- Guard both direct table access and server-side answer/homework checks.
create or replace function private.is_student() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.profiles p join public.enrollments e on e.student_id=p.id
 join public.profiles t on t.id=e.teacher_id and t.role='teacher'
 where p.id=auth.uid() and p.role='student' and not p.must_change_password);
$$;
-- Pending students must still read their profile and enrollment to finish setup.
create or replace function private.has_access() returns boolean language sql stable security definer set search_path='' as $$
 select private.is_teacher() or exists(select 1 from public.profiles p join public.enrollments e on e.student_id=p.id
 join public.profiles t on t.id=e.teacher_id and t.role='teacher' where p.id=auth.uid() and p.role='student');
$$;
do $$ declare target text; begin
 foreach target in array array['tasks','attempts','slides','assignments','learning_blocks','homework','homework_blocks'] loop
 execute format('create policy password_setup_required on public.%I as restrictive to authenticated using(private.password_ready()) with check(private.password_ready())',target);
 end loop;
end $$;
commit;
