-- Run once in a NEW Supabase project, as postgres, using SQL Editor.
begin;
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;
grant usage on schema private to authenticated;
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 name text not null check(length(name) between 1 and 80), email text not null,
 role text not null default 'student' check(role in ('student','teacher'))
);
create table public.groups (
 id uuid primary key default gen_random_uuid(), teacher_id uuid not null references public.profiles(id),
 name text not null check(length(name) between 1 and 80), unique(id,teacher_id), unique(teacher_id,name)
);
create table public.enrollments (
 student_id uuid primary key references public.profiles(id) on delete cascade,
 teacher_id uuid not null references public.profiles(id), group_id uuid references public.groups(id) on delete set null
);
create table public.tasks (
 id uuid primary key default gen_random_uuid(), teacher_id uuid references public.profiles(id),
 module integer not null check(module between 1 and 27), title text not null check(length(title) between 1 and 150),
 statement text not null check(length(statement) between 1 and 20000), difficulty text not null default 'Базовый',
 hint text not null default '', published boolean not null default false
);
create table private.task_keys (
 task_id uuid primary key references public.tasks(id) on delete cascade,
 answer text not null check(length(answer) between 1 and 500), solution text not null default ''
);
create table public.attempts (
 id uuid primary key default gen_random_uuid(), student_id uuid not null references public.profiles(id) on delete cascade,
 task_id uuid not null references public.tasks(id) on delete cascade, answer text not null check(length(answer) between 1 and 500),
 correct boolean not null, duration integer not null check(duration between 0 and 86400), created_at timestamptz not null default now()
);
create table public.slides (
 student_id uuid not null references public.profiles(id) on delete cascade, module integer not null check(module = 5),
 slide integer not null check(slide between 0 and 2), primary key(student_id,module,slide)
);
create table public.assignments (
 id uuid primary key default gen_random_uuid(), teacher_id uuid not null references public.profiles(id),
 task_id uuid not null references public.tasks(id) on delete cascade,
 student_id uuid references public.profiles(id) on delete cascade,
 group_id uuid references public.groups(id) on delete cascade, due_date date,
 check((student_id is null) <> (group_id is null))
);
create index on public.enrollments(teacher_id);
create index on public.enrollments(group_id);
create index on public.tasks(teacher_id);
create index on public.attempts(student_id,task_id);
create index on public.assignments(teacher_id);
create index on public.assignments(group_id);
create index on public.assignments(student_id);

create function private.is_teacher() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.profiles where id=auth.uid() and role='teacher');
$$;
create function private.is_student() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.profiles where id=auth.uid() and role='student');
$$;
create function private.owns_student(student uuid) returns boolean language sql stable security definer set search_path='' as $$
 select private.is_teacher() and exists(select 1 from public.enrollments where student_id=student and teacher_id=auth.uid());
$$;
create function private.own_teacher() returns uuid language sql stable security definer set search_path='' as $$
 select teacher_id from public.enrollments where student_id=auth.uid();
$$;
create function private.own_group() returns uuid language sql stable security definer set search_path='' as $$
 select group_id from public.enrollments where student_id=auth.uid();
$$;
create function private.can_read_task(task uuid) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.tasks where id=task and (teacher_id=auth.uid() or (published and (teacher_id is null or teacher_id=private.own_teacher()))));
$$;
create function private.new_profile() returns trigger language plpgsql security definer set search_path='' as $$
 begin insert into public.profiles(id,name,email,role) values(new.id,left(coalesce(nullif(trim(new.raw_user_meta_data->>'name'),''),'Ученик'),80),new.email,'student');return new;end;
$$;
create trigger on_auth_user_created after insert on auth.users for each row execute function private.new_profile();
-- Existing Auth users are deliberately assigned student role too.
insert into public.profiles(id,name,email) select id,left(coalesce(nullif(trim(raw_user_meta_data->>'name'),''),'Ученик'),80),email from auth.users on conflict do nothing;

alter table public.profiles enable row level security;
alter table public.groups enable row level security;
alter table public.enrollments enable row level security;
alter table public.tasks enable row level security;
alter table public.attempts enable row level security;
alter table public.slides enable row level security;
alter table public.assignments enable row level security;
alter table private.task_keys enable row level security;
revoke all on public.profiles,public.groups,public.enrollments,public.tasks,public.attempts,public.slides,public.assignments from anon,authenticated;
revoke all on private.task_keys from public,anon,authenticated;
grant select on public.profiles,public.groups,public.enrollments,public.tasks,public.attempts,public.slides,public.assignments to authenticated;
grant insert,delete on public.groups to authenticated;
grant update(group_id),delete on public.enrollments to authenticated;
grant delete on public.tasks to authenticated;
grant insert,update on public.slides to authenticated;
grant insert,delete on public.assignments to authenticated;
create policy profiles_read on public.profiles for select to authenticated using(id=auth.uid() or private.owns_student(id));
create policy groups_read on public.groups for select to authenticated using(teacher_id=auth.uid() or id=private.own_group());
create policy groups_insert on public.groups for insert to authenticated with check(teacher_id=auth.uid() and private.is_teacher());
create policy groups_delete on public.groups for delete to authenticated using(teacher_id=auth.uid() and private.is_teacher());
create policy enrollments_read on public.enrollments for select to authenticated using(student_id=auth.uid() or (teacher_id=auth.uid() and private.is_teacher()));
create policy enrollments_update on public.enrollments for update to authenticated using(teacher_id=auth.uid() and private.is_teacher()) with check(teacher_id=auth.uid() and (group_id is null or exists(select 1 from public.groups g where g.id=group_id and g.teacher_id=auth.uid())));
create policy enrollments_delete on public.enrollments for delete to authenticated using(teacher_id=auth.uid() and private.is_teacher());
create policy tasks_read on public.tasks for select to authenticated using(private.can_read_task(id));
create policy tasks_delete on public.tasks for delete to authenticated using(teacher_id=auth.uid() and private.is_teacher());
create policy attempts_read on public.attempts for select to authenticated using(student_id=auth.uid() or private.owns_student(student_id));
create policy slides_read on public.slides for select to authenticated using(student_id=auth.uid() or private.owns_student(student_id));
create policy slides_insert on public.slides for insert to authenticated with check(student_id=auth.uid() and private.is_student());
create policy slides_update on public.slides for update to authenticated using(student_id=auth.uid() and private.is_student()) with check(student_id=auth.uid() and private.is_student());
create policy assignments_read on public.assignments for select to authenticated using((teacher_id=auth.uid() and private.is_teacher()) or (teacher_id=private.own_teacher() and (student_id=auth.uid() or group_id=private.own_group())));
create policy assignments_insert on public.assignments for insert to authenticated with check(
 teacher_id=auth.uid() and private.is_teacher()
 and exists(select 1 from public.tasks t where t.id=task_id and t.published and (t.teacher_id is null or t.teacher_id=auth.uid()))
 and ((student_id is not null and private.owns_student(student_id)) or (group_id is not null and exists(select 1 from public.groups g where g.id=group_id and g.teacher_id=auth.uid())))
);
create policy assignments_delete on public.assignments for delete to authenticated using(teacher_id=auth.uid() and private.is_teacher());

create function public.enroll_student(student_email text,selected_group uuid default null) returns void language plpgsql security definer set search_path='' as $$
 declare student uuid;
 begin
 if not private.is_teacher() then raise exception 'Только преподаватель может добавлять учеников';end if;
 if selected_group is not null and not exists(select 1 from public.groups where id=selected_group and teacher_id=auth.uid()) then raise exception 'Группа недоступна';end if;
 select id into student from public.profiles where lower(email)=lower(trim(student_email)) and role='student';
 if student is null then raise exception 'Ученик не найден. Сначала он должен зарегистрироваться';end if;
 if exists(select 1 from public.enrollments where student_id=student) then raise exception 'Ученик уже прикреплён к преподавателю';end if;
 insert into public.enrollments(student_id,teacher_id,group_id) values(student,auth.uid(),selected_group);
 end;
$$;
create function public.save_task(task_data jsonb) returns void language plpgsql security definer set search_path='' as $$
 declare task uuid := (task_data->>'id')::uuid; existed boolean; new_answer text := nullif(trim(task_data->>'answer'),'');
 begin
 if not private.is_teacher() then raise exception 'Нет доступа';end if;
 select exists(select 1 from public.tasks where id=task) into existed;
 if existed and not exists(select 1 from public.tasks where id=task and teacher_id=auth.uid()) then raise exception 'Нет доступа к задаче';end if;
 if not existed and new_answer is null then raise exception 'Укажите правильный ответ';end if;
 insert into public.tasks(id,teacher_id,module,title,statement,difficulty,hint,published)
 values(task,auth.uid(),(task_data->>'module')::integer,trim(task_data->>'title'),trim(task_data->>'statement'),task_data->>'difficulty',coalesce(task_data->>'hint',''),coalesce((task_data->>'published')::boolean,false))
 on conflict(id) do update set module=excluded.module,title=excluded.title,statement=excluded.statement,difficulty=excluded.difficulty,hint=excluded.hint,published=excluded.published;
 if existed then update private.task_keys set answer=coalesce(new_answer,answer),solution=coalesce(nullif(task_data->>'solution',''),solution) where task_id=task;
 else insert into private.task_keys(task_id,answer,solution) values(task,new_answer,coalesce(task_data->>'solution',''));end if;
 end;
$$;
create function public.submit_answer(selected_task uuid,submitted_answer text,elapsed_seconds integer default 0) returns jsonb language plpgsql security definer set search_path='' as $$
 declare expected text; explanation text; is_correct boolean;
 begin
 if not private.is_student() then raise exception 'Войдите как ученик';end if;
 if not private.can_read_task(selected_task) or not exists(select 1 from public.tasks where id=selected_task and published) then raise exception 'Задача недоступна';end if;
 if length(trim(submitted_answer)) not between 1 and 500 then raise exception 'Введите ответ длиной от 1 до 500 символов';end if;
 select answer,solution into expected,explanation from private.task_keys where task_id=selected_task;
 if expected is null then raise exception 'Для задачи ещё не настроена проверка';end if;
 is_correct := lower(trim(submitted_answer))=lower(trim(expected));
 insert into public.attempts(student_id,task_id,answer,correct,duration) values(auth.uid(),selected_task,trim(submitted_answer),is_correct,greatest(0,least(coalesce(elapsed_seconds,0),86400)));
 return jsonb_build_object('correct',is_correct,'solution',explanation);
 end;
$$;
revoke execute on all functions in schema private from public,anon,authenticated;
grant execute on function private.is_teacher(),private.is_student(),private.owns_student(uuid),private.own_teacher(),private.own_group(),private.can_read_task(uuid) to authenticated;
revoke execute on function public.enroll_student(text,uuid),public.save_task(jsonb),public.submit_answer(uuid,text,integer) from public,anon,authenticated;
grant execute on function public.enroll_student(text,uuid),public.save_task(jsonb),public.submit_answer(uuid,text,integer) to authenticated;
insert into public.tasks(id,module,title,statement,difficulty,hint,published) values
 ('00000000-0000-4000-8000-000000000051',5,'Двоичная запись','К двоичной записи натурального N справа дописывается 0. Какой результат получится при N = 13?','Базовый','Сдвиг на один разряд влево умножает число на 2.',true),
 ('00000000-0000-4000-8000-000000000052',5,'Бит чётности','К двоичной записи N справа дописывается остаток от деления количества единиц в записи на 2. Какой результат получится при N = 11?','Базовый','Посчитайте единицы в двоичной записи числа 11.',true),
 ('00000000-0000-4000-8000-000000000053',5,'Найди минимальное N','К двоичной записи N справа дописывается 1. Найди минимальное натуральное N, при котором полученное число R больше 35.','Средний','Выразите R через N.',true);
insert into private.task_keys(task_id,answer,solution) values
 ('00000000-0000-4000-8000-000000000051','26','13 = 1101₂. Дописываем 0: 11010₂ = 26.'),
 ('00000000-0000-4000-8000-000000000052','23','11 = 1011₂. Единиц три, дописываем 1: 10111₂ = 23.'),
 ('00000000-0000-4000-8000-000000000053','18','2N + 1 > 35, значит N > 17. Минимальное натуральное N = 18.');
commit;
