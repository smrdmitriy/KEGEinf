begin;
-- Old creation placed the full 'given name surname' value in first_name.
update public.profiles set last_name=left(trim(substring(first_name from position(' ' in trim(first_name))+1)),40),first_name=split_part(trim(first_name),' ',1)
 where role='student' and last_name='' and trim(first_name) like '% %';
update public.profiles set last_name=left(trim(substring(name from position(' ' in trim(name))+1)),40),first_name=split_part(trim(name),' ',1)
 where role='student' and last_name='' and first_name='' and trim(name) like '% %';
create or replace function public.complete_student_enrollment(student uuid, teacher uuid, selected_group uuid default null) returns void language plpgsql security definer set search_path='' as $$
declare meta jsonb; given text; family text;
begin
 if not exists(select 1 from public.profiles where id=teacher and role='teacher') then raise exception 'Преподаватель недоступен';end if;
 if not exists(select 1 from public.profiles where id=student and role='student') then raise exception 'Ученик недоступен';end if;
 if selected_group is not null and not exists(select 1 from public.groups where id=selected_group and teacher_id=teacher) then raise exception 'Группа недоступна';end if;
 select raw_user_meta_data into meta from auth.users where id=student;
 given:=coalesce(nullif(trim(meta->>'first_name'),''),split_part(trim(meta->>'name'),' ',1));
 family:=coalesce(nullif(trim(meta->>'last_name'),''),nullif(trim(substring(meta->>'name' from position(' ' in trim(meta->>'name'))+1)),''));
 if given is not null and family is not null then
 update public.profiles set first_name=left(given,40),last_name=left(family,40),school_class=left(coalesce(trim(meta->>'school_class'),''),20) where id=student;
 end if;
 insert into public.enrollments(student_id,teacher_id,group_id) values(student,teacher,selected_group);
end;$$;
create function public.set_student_class(student uuid, selected_class text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.is_teacher() or not private.owns_student(student) or selected_class is null or length(trim(selected_class))>20 then raise exception 'Нет доступа или неверный класс';end if;
 update public.profiles set school_class=trim(selected_class) where id=student and role='student';
end;$$;
revoke all on function public.set_student_class(uuid,text) from public,anon;
grant execute on function public.set_student_class(uuid,text) to authenticated;
-- A reset always restores the first-login requirement, including an unchanged password hash.
create or replace function private.track_student_password() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if new.raw_app_meta_data->>'password_reset_nonce' is distinct from old.raw_app_meta_data->>'password_reset_nonce' then
 update public.profiles set must_change_password=true where id=new.id and role='student';
 elsif new.encrypted_password is distinct from old.encrypted_password then
 update public.profiles set must_change_password=false where id=new.id and role='student';
 end if;
 return new;
end;$$;
do $$ declare target text;
begin
 if exists(select 1 from pg_publication where pubname='supabase_realtime') then
 foreach target in array array['profiles','enrollments','groups'] loop
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename=target) then
 execute format('alter publication supabase_realtime add table public.%I',target);
 end if;
 end loop;
 end if;
end $$;
commit;
