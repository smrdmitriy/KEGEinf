-- Preserve ownership when access is revoked; an email alone cannot claim an account.
begin;
create table private.student_owners (
 student_id uuid primary key references public.profiles(id) on delete cascade,
 teacher_id uuid not null references public.profiles(id) on delete cascade
);
revoke all on private.student_owners from public,anon,authenticated;
insert into private.student_owners select student_id,teacher_id from public.enrollments;
create function private.remember_student_owner() returns trigger
language plpgsql security definer set search_path='' as $$
begin
 if TG_OP='DELETE' then
  insert into private.student_owners values(old.student_id,old.teacher_id)
  on conflict(student_id) do update set teacher_id=excluded.teacher_id;
  return old;
 end if;
 insert into private.student_owners values(new.student_id,new.teacher_id)
 on conflict(student_id) do update set teacher_id=excluded.teacher_id;
 return new;
end;
$$;
revoke all on function private.remember_student_owner() from public,anon,authenticated;
create trigger remember_student_owner after insert or update on public.enrollments
 for each row execute function private.remember_student_owner();
create trigger remember_removed_student before delete on public.enrollments
 for each row execute function private.remember_student_owner();

create function public.restore_student(student_email text, selected_group uuid default null)
returns boolean language plpgsql security definer set search_path='' as $$
declare pupil uuid;
begin
 if not private.is_teacher() then raise exception 'Только преподаватель может восстановить ученика'; end if;
 if selected_group is not null and not exists(select 1 from public.groups where id=selected_group and teacher_id=auth.uid()) then raise exception 'Группа недоступна'; end if;
 select p.id into pupil from public.profiles p join private.student_owners o on o.student_id=p.id
 where lower(p.email)=lower(trim(student_email)) and p.role='student' and o.teacher_id=auth.uid()
 for update of p,o;
 if pupil is null then return false; end if;
 if exists(select 1 from public.enrollments where student_id=pupil) then raise exception 'Ученик уже добавлен'; end if;
 insert into public.enrollments(student_id,teacher_id,group_id) values(pupil,auth.uid(),selected_group);
 return true;
end;
$$;
revoke all on function public.restore_student(text,uuid) from public,anon;
grant execute on function public.restore_student(text,uuid) to authenticated;
commit;
