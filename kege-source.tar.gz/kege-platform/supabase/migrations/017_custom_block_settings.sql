begin;
alter table public.task_folders
 add column description text not null default 'Теория, классная и домашняя работа' check(length(trim(description)) between 1 and 300),
 add column icon text not null default 'Network' check(icon in ('Network','Table2','Database','Binary'));
create function private.protect_standard_block() returns trigger language plpgsql set search_path='' as $$
begin
 if old.standard_number is not null then raise exception 'Стандартные блоки №1–27 удалять нельзя';end if;
 return old;
end;$$;
revoke all on function private.protect_standard_block() from public,anon,authenticated;
create trigger protect_standard_block before delete on public.task_folders for each row execute function private.protect_standard_block();
create function public.delete_study_block(selected_block uuid) returns void language plpgsql security definer set search_path='' as $$
declare block public.task_folders;
begin
 if not private.is_teacher() then raise exception 'Нет доступа';end if;
 select * into block from public.task_folders where id=selected_block and teacher_id=auth.uid() for update;
 if block.id is null then raise exception 'Блок недоступен';end if;
 if block.standard_number is not null then raise exception 'Стандартные блоки №1–27 удалять нельзя';end if;
 delete from public.tasks where folder_id=block.id and teacher_id=auth.uid();
 delete from public.task_folders where id=block.id;
end;$$;
revoke all on function public.delete_study_block(uuid) from public,anon;
grant execute on function public.delete_study_block(uuid) to authenticated;
drop function public.block_catalog();
create function public.block_catalog() returns table(id uuid,name text,standard_number integer,can_open boolean,description text,icon text) language sql stable security definer set search_path='' as $$
 select f.id,f.name,f.standard_number,private.can_open_study_block(f.id),f.description,f.icon from public.task_folders f
 where f.teacher_id=case when private.is_teacher() then auth.uid() when auth.uid() is not null then private.own_teacher() else '6645f06d-3371-4695-b58a-c926222e6515'::uuid end
 order by f.standard_number nulls last,f.name;
$$;
revoke all on function public.block_catalog() from public;
grant execute on function public.block_catalog() to anon,authenticated;
commit;
