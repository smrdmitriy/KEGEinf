-- Auth admin hard-delete cascades all student data. Disable the former unlink/restore workflow.
begin;
drop trigger remember_removed_student on public.enrollments;
drop trigger remember_student_owner on public.enrollments;
drop function private.remember_student_owner();
revoke execute on function public.restore_student(text,uuid) from authenticated;
revoke delete on public.enrollments from authenticated;
commit;
