begin;
alter table public.task_folders add column theory_format text not null default 'text' check(theory_format in ('text','html'));
alter table public.task_folders add column theory_html text not null default '' check(octet_length(theory_html)<=2097152);
create function public.save_block_theory(selected_block uuid,selected_format text,html_document text,plain_theory text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.is_teacher() or not exists(select 1 from public.task_folders where id=selected_block and teacher_id=auth.uid()) then raise exception 'Блок недоступен';end if;
 if selected_format is null or selected_format not in ('text','html') or plain_theory is null or length(plain_theory)>100000 or html_document is null or octet_length(html_document)>2097152 or (selected_format='html' and length(trim(html_document))=0) then raise exception 'Проверьте формат и размер теории';end if;
 update public.task_folders set theory=plain_theory,theory_format=selected_format,theory_html=html_document where id=selected_block and teacher_id=auth.uid();
end;$$;
revoke all on function public.save_block_theory(uuid,text,text,text) from public,anon;
grant execute on function public.save_block_theory(uuid,text,text,text) to authenticated;
commit;
