begin;
update public.tasks set title=regexp_replace(title,'^Из документа · ','') where title like 'Из документа · %';
alter table public.homework add column task_id uuid references public.tasks(id) on delete cascade;
create function public.send_task_solution(selected_task uuid,selected_module integer,task_text text,solution_code text default '',solution_image text default '') returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.is_student() or not private.can_read_task(selected_task) or not exists(select 1 from public.tasks where id=selected_task and module=selected_module) or not exists(select 1 from public.attempts where task_id=selected_task and student_id=auth.uid() and correct) then raise exception 'Сначала решите доступную задачу';end if;
 insert into public.homework(student_id,module,task_id,statement,code,image) select auth.uid(),module,id,title||E'\n'||statement,coalesce(solution_code,''),coalesce(solution_image,'') from public.tasks where id=selected_task;
end;$$;
create function public.assign_class_block(school_class text,selected_module integer,selected_student uuid default null,selected_group uuid default null) returns void language plpgsql security definer set search_path='' as $$
declare pupil uuid; total integer:=0;
begin
 if not private.is_teacher() or nullif(trim(school_class),'') is null then raise exception 'Выберите класс';end if;
 for pupil in select p.id from public.profiles p join public.enrollments e on e.student_id=p.id where e.teacher_id=auth.uid() and p.school_class=assign_class_block.school_class loop
 perform public.assign_block(selected_module,pupil,null);total:=total+1;
 end loop;
 if total=0 then raise exception 'В классе нет ваших учеников';end if;
end;$$;
create function public.assign_class_homework(school_class text,selected_module integer,selected_student uuid default null,selected_group uuid default null,deadline date default null) returns void language plpgsql security definer set search_path='' as $$
declare pupil uuid; total integer:=0;
begin
 if not private.is_teacher() or nullif(trim(school_class),'') is null then raise exception 'Выберите класс';end if;
 for pupil in select p.id from public.profiles p join public.enrollments e on e.student_id=p.id where e.teacher_id=auth.uid() and p.school_class=assign_class_homework.school_class loop
 perform public.assign_homework_block(selected_module,pupil,null,deadline);total:=total+1;
 end loop;
 if total=0 then raise exception 'В классе нет ваших учеников';end if;
end;$$;
revoke all on function public.send_task_solution(uuid,integer,text,text,text),public.assign_class_block(text,integer,uuid,uuid),public.assign_class_homework(text,integer,uuid,uuid,date) from public,anon;
grant execute on function public.send_task_solution(uuid,integer,text,text,text),public.assign_class_block(text,integer,uuid,uuid),public.assign_class_homework(text,integer,uuid,uuid,date) to authenticated;
create or replace function public.review_homework(homework_id uuid, decision text, comment text default '') returns void language plpgsql security definer set search_path='' as $$
declare h public.homework;
begin
 select * into h from public.homework where id=homework_id;
 if h.id is null or not private.owns_student(h.student_id) or decision not in ('accepted','revision') or decision is null then raise exception 'Нет доступа или неверный статус';end if;
 update public.homework set status=decision,feedback=coalesce(comment,'') where id=h.id;
 if decision='accepted' and h.task_id is null then update public.learning_blocks set completed=true where student_id=h.student_id and module=h.module and teacher_id=auth.uid();end if;
end;$$;
commit;
