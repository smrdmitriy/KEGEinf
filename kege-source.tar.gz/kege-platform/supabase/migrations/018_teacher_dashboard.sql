begin;
alter table public.task_folders drop constraint task_folders_icon_check;
alter table public.task_folders add constraint task_folders_icon_check check(icon in ('Network','Table2','Database','Binary','Workflow','Pentagon','Image','Boxes','Sheet','Search','HardDrive','Replace','Globe','Braces','GitBranch','ListOrdered','Route','Flag','Cpu','Terminal','TextCursorInput','Hash','ArrowDownWideNarrow','ChartNoAxesCombined'));
create function public.teacher_task_answer(selected_task uuid) returns text language plpgsql stable security definer set search_path='' as $$
declare result text;
begin
 if not private.is_teacher() or not exists(select 1 from public.tasks where id=selected_task and teacher_id=auth.uid()) then raise exception 'Нет доступа';end if;
 select answer into result from private.task_keys where task_id=selected_task;return result;
end;$$;
create function public.teacher_ranking() returns table(student_id uuid,name text,last_login timestamptz,solved bigint,errors bigint,seconds bigint,blocks jsonb) language plpgsql stable security definer set search_path='' as $$
begin
 if not private.is_teacher() then raise exception 'Нет доступа';end if;
 return query
 select p.id,p.name,u.last_sign_in_at,
 (select count(distinct a.task_id) from public.attempts a where a.student_id=p.id and a.correct),
 (select count(*) from public.attempts a where a.student_id=p.id and not a.correct),
 (select coalesce(sum(a.duration),0) from public.attempts a where a.student_id=p.id),
 coalesce((select jsonb_agg(jsonb_build_object('id',f.id,'name',f.name,'solved',(select count(distinct a.task_id) from public.attempts a join public.tasks t on t.id=a.task_id where a.student_id=p.id and a.correct and t.folder_id=f.id),'total',(select count(*) from public.tasks t where t.folder_id=f.id and t.published),'seconds',(select coalesce(sum(a.duration),0) from public.attempts a join public.tasks t on t.id=a.task_id where a.student_id=p.id and t.folder_id=f.id)) order by f.standard_number nulls last,f.name) from public.study_block_members m join public.task_folders f on f.id=m.block_id where m.student_id=p.id and f.teacher_id=auth.uid()),'[]'::jsonb)
 from public.enrollments e join public.profiles p on p.id=e.student_id join auth.users u on u.id=p.id where e.teacher_id=auth.uid()
 order by 4 desc,6 asc,p.name;
end;$$;
revoke all on function public.teacher_task_answer(uuid),public.teacher_ranking() from public,anon;
grant execute on function public.teacher_task_answer(uuid),public.teacher_ranking() to authenticated;
commit;
