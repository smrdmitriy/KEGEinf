begin;
alter table public.task_folders add column standard_number integer check(standard_number between 1 and 27);
update public.task_folders set standard_number=module where name='Задание №'||module and work_type='classwork';
alter table public.task_folders add constraint one_standard_block unique(teacher_id,standard_number);
update public.task_folders set name='Информационные модели' where standard_number=1;
update public.task_folders set name='Таблицы истинности' where standard_number=2;
update public.task_folders set name='Базы данных' where standard_number=3;
update public.task_folders set name='Кодирование информации' where standard_number=4;
update public.task_folders set name='Анализ алгоритмов' where standard_number=5;
update public.task_folders set name='Исполнитель «Черепаха»' where standard_number=6;
update public.task_folders set name='Изображения и звук' where standard_number=7;
update public.task_folders set name='Комбинаторика' where standard_number=8;
update public.task_folders set name='Электронные таблицы' where standard_number=9;
update public.task_folders set name='Поиск в тексте' where standard_number=10;
update public.task_folders set name='Количество информации' where standard_number=11;
update public.task_folders set name='Исполнитель «Редактор»' where standard_number=12;
update public.task_folders set name='IP-адресация' where standard_number=13;
update public.task_folders set name='Системы счисления' where standard_number=14;
update public.task_folders set name='Алгебра логики' where standard_number=15;
update public.task_folders set name='Рекурсивные алгоритмы' where standard_number=16;
update public.task_folders set name='Числовые последовательности' where standard_number=17;
update public.task_folders set name='Динамическое программирование' where standard_number=18;
update public.task_folders set name='Теория игр: первый ход' where standard_number=19;
update public.task_folders set name='Теория игр: стратегия' where standard_number=20;
update public.task_folders set name='Теория игр: анализ' where standard_number=21;
update public.task_folders set name='Параллельные процессы' where standard_number=22;
update public.task_folders set name='Исполнитель и команды' where standard_number=23;
update public.task_folders set name='Обработка строк' where standard_number=24;
update public.task_folders set name='Обработка целых чисел' where standard_number=25;
update public.task_folders set name='Сортировка и отбор' where standard_number=26;
update public.task_folders set name='Анализ больших данных' where standard_number=27;
create or replace function public.ensure_standard_blocks() returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.is_teacher() then raise exception 'Нет доступа';end if;
 insert into public.task_folders(teacher_id,module,standard_number,work_type,name)
 select auth.uid(),n,n,'classwork',title from (values (1,'Информационные модели'),(2,'Таблицы истинности'),(3,'Базы данных'),(4,'Кодирование информации'),(5,'Анализ алгоритмов'),(6,'Исполнитель «Черепаха»'),(7,'Изображения и звук'),(8,'Комбинаторика'),(9,'Электронные таблицы'),(10,'Поиск в тексте'),(11,'Количество информации'),(12,'Исполнитель «Редактор»'),(13,'IP-адресация'),(14,'Системы счисления'),(15,'Алгебра логики'),(16,'Рекурсивные алгоритмы'),(17,'Числовые последовательности'),(18,'Динамическое программирование'),(19,'Теория игр: первый ход'),(20,'Теория игр: стратегия'),(21,'Теория игр: анализ'),(22,'Параллельные процессы'),(23,'Исполнитель и команды'),(24,'Обработка строк'),(25,'Обработка целых чисел'),(26,'Сортировка и отбор'),(27,'Анализ больших данных')) names(n,title)
 on conflict(teacher_id,standard_number) do nothing;
end;$$;
create function public.block_catalog() returns table(id uuid,name text,standard_number integer,can_open boolean) language sql stable security definer set search_path='' as $$
 select f.id,f.name,f.standard_number,private.can_open_study_block(f.id) from public.task_folders f
 where f.teacher_id=case when private.is_teacher() then auth.uid() when auth.uid() is not null then private.own_teacher() else '6645f06d-3371-4695-b58a-c926222e6515'::uuid end
 order by f.standard_number nulls last,f.name;
$$;
revoke all on function public.block_catalog() from public;
grant execute on function public.block_catalog() to anon,authenticated;
commit;
