begin;
alter table public.profiles add column first_name text not null default '' check(length(first_name)<=40), add column last_name text not null default '' check(length(last_name)<=40), add column school_class text not null default '' check(length(school_class)<=20), add column avatar text not null default '' check(length(avatar)<=120000 and (avatar='' or avatar ~ '^data:image/jpeg;base64,[A-Za-z0-9+/=]+$'));
update public.profiles set first_name=left(name,40);
create function public.save_profile(first_name text,last_name text,school_class text,avatar text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.has_access() then raise exception 'Нет доступа'; end if;
 if first_name is null or length(trim(first_name)) not between 1 and 40 or last_name is null or length(trim(last_name))>40 or school_class is null or length(trim(school_class))>20 or avatar is null then raise exception 'Проверьте поля профиля'; end if;
 update public.profiles p set first_name=trim(save_profile.first_name),last_name=trim(save_profile.last_name),school_class=trim(save_profile.school_class),avatar=save_profile.avatar,name=trim(trim(save_profile.last_name)||' '||trim(save_profile.first_name)) where p.id=auth.uid();
end; $$;
revoke all on function public.save_profile(text,text,text,text) from public,anon;
grant execute on function public.save_profile(text,text,text,text) to authenticated;
commit;
