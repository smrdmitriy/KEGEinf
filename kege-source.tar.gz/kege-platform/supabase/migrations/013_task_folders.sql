begin;
create table public.task_folders (
 id uuid primary key default gen_random_uuid(),
 teacher_id uuid not null references public.profiles(id),
 module integer not null check(module between 1 and 27),
 work_type text not null check(work_type in ('classwork','homework')),
 name text not null check(length(trim(name)) between 1 and 100),
 unique(teacher_id,module,work_type,name)
);
alter table public.task_folders enable row level security;
revoke all on public.task_folders from public,anon,authenticated;
grant select,insert on public.task_folders to authenticated;
create policy folders_read on public.task_folders for select to authenticated using(private.is_teacher() and teacher_id=auth.uid());
create policy folders_insert on public.task_folders for insert to authenticated with check(private.is_teacher() and teacher_id=auth.uid());
alter table public.tasks add column folder_id uuid references public.task_folders(id);
alter function public.save_task(jsonb) rename to save_task_without_folder;
revoke all on function public.save_task_without_folder(jsonb) from public,anon,authenticated;
create function public.save_task(task_data jsonb) returns void language plpgsql security definer set search_path='' as $$
declare destination public.task_folders; selected_folder uuid;
begin
 if not private.is_teacher() then raise exception 'Нет доступа';end if;
 if task_data ? 'folder_id' then selected_folder:=nullif(task_data->>'folder_id','')::uuid;
 else select folder_id into selected_folder from public.tasks where id=(task_data->>'id')::uuid and teacher_id=auth.uid();end if;
 if selected_folder is not null then
  select * into destination from public.task_folders where id=selected_folder and teacher_id=auth.uid();
  if destination.id is null then raise exception 'Папка недоступна';end if;
  if destination.module<>(task_data->>'module')::integer or destination.work_type<>coalesce(task_data->>'work_type','classwork') then selected_folder:=null;end if;
 end if;
 perform public.save_task_without_folder(task_data);
 update public.tasks set folder_id=selected_folder where id=(task_data->>'id')::uuid and teacher_id=auth.uid();
end;$$;
create function public.move_task(selected_task uuid,selected_folder uuid,selected_module integer,selected_work_type text) returns void language plpgsql security definer set search_path='' as $$
declare destination public.task_folders;
begin
 if not private.is_teacher() then raise exception 'Нет доступа';end if;
 if selected_folder is not null then
  select * into destination from public.task_folders where id=selected_folder and teacher_id=auth.uid();
  if destination.id is null then raise exception 'Папка недоступна';end if;
  selected_module:=destination.module;selected_work_type:=destination.work_type;
 end if;
 update public.tasks set folder_id=selected_folder,module=selected_module,work_type=selected_work_type where id=selected_task and teacher_id=auth.uid();
 if not found then raise exception 'Задача недоступна';end if;
end;$$;
revoke all on function public.save_task(jsonb),public.move_task(uuid,uuid,integer,text) from public,anon;
grant execute on function public.save_task(jsonb),public.move_task(uuid,uuid,integer,text) to authenticated;
commit;
