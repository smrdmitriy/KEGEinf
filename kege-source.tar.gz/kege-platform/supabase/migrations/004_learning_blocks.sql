begin;
-- Retire examples without destroying student history.
update public.tasks set published=false where teacher_id is null and id in ('00000000-0000-4000-8000-000000000051','00000000-0000-4000-8000-000000000052','00000000-0000-4000-8000-000000000053');
create table public.learning_blocks (
 student_id uuid not null references public.profiles(id) on delete cascade,
 teacher_id uuid not null references public.profiles(id),
 module integer not null check(module between 1 and 27),
 completed boolean not null default false,
 primary key(student_id,module)
);
create table public.homework (
 id uuid primary key default gen_random_uuid(),
 student_id uuid not null references public.profiles(id) on delete cascade,
 module integer not null check(module between 1 and 27),
 statement text not null check(length(trim(statement)) between 1 and 20000),
 code text not null default '' check(length(code)<=50000),
 image text not null default '' check(image='' or (length(image)<=1400000 and image ~ '^data:image/jpeg;base64,[A-Za-z0-9+/=]+$')),
 status text not null default 'pending' check(status in ('pending','accepted','revision')),
 feedback text not null default '' check(length(feedback)<=5000),
 created_at timestamptz not null default now(),
 check(length(trim(code))>0 or image<>'')
);
create index on public.homework(student_id,module);
alter table public.learning_blocks enable row level security;
alter table public.homework enable row level security;
revoke all on public.learning_blocks,public.homework from public,anon,authenticated;
grant select on public.learning_blocks,public.homework to authenticated;
create policy blocks_read on public.learning_blocks for select to authenticated using(private.has_access() and ((student_id=auth.uid() and teacher_id=private.own_teacher()) or (teacher_id=auth.uid() and private.owns_student(student_id))));
create policy homework_read on public.homework for select to authenticated using(private.has_access() and (student_id=auth.uid() or private.owns_student(student_id)));
create function private.block_done(student uuid, block integer) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.learning_blocks b join public.enrollments e on e.student_id=b.student_id and e.teacher_id=b.teacher_id where b.student_id=student and b.module=block and (b.completed or
 (exists(select 1 from public.tasks t where t.teacher_id=b.teacher_id and t.module=block and t.published)
 and not exists(select 1 from public.tasks t where t.teacher_id=b.teacher_id and t.module=block and t.published and not exists(select 1 from public.attempts a where a.student_id=student and a.task_id=t.id and a.correct)))));
$$;
create function private.block_open(student uuid, block integer) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.learning_blocks b join public.enrollments e on e.student_id=b.student_id and e.teacher_id=b.teacher_id where b.student_id=student and b.module=block)
 and not exists(select 1 from public.learning_blocks b join public.enrollments e on e.student_id=b.student_id and e.teacher_id=b.teacher_id where b.student_id=student and b.module<block and not private.block_done(student,b.module));
$$;
create function public.block_status() returns table(module integer, unlocked boolean, completed boolean) language sql stable security definer set search_path='' as $$
 select b.module,private.block_open(auth.uid(),b.module),private.block_done(auth.uid(),b.module) from public.learning_blocks b where b.student_id=auth.uid() and b.teacher_id=private.own_teacher() and private.is_student();
$$;
create or replace function private.can_read_task(task uuid) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.tasks t where t.id=task and
 ((private.is_teacher() and (t.teacher_id=auth.uid() or (t.teacher_id is null and t.published)))
 or (private.is_student() and t.published and t.teacher_id=private.own_teacher() and private.block_open(auth.uid(),t.module))));
$$;
create policy slides_block_access on public.slides as restrictive to authenticated using(private.is_teacher() or private.block_open(auth.uid(),module)) with check(private.is_student() and private.block_open(auth.uid(),module));
create function public.assign_block(selected_module integer, selected_student uuid default null, selected_group uuid default null) returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.is_teacher() or selected_module not between 1 and 27 or selected_module is null or (selected_student is null)=(selected_group is null) then raise exception 'Неверное назначение';end if;
 if selected_student is not null and not private.owns_student(selected_student) then raise exception 'Ученик недоступен';end if;
 if selected_group is not null and not exists(select 1 from public.groups where id=selected_group and teacher_id=auth.uid()) then raise exception 'Группа недоступна';end if;
 insert into public.learning_blocks(student_id,teacher_id,module)
 select student_id,auth.uid(),selected_module from public.enrollments where teacher_id=auth.uid() and (student_id=selected_student or group_id=selected_group)
 on conflict(student_id,module) do update set teacher_id=excluded.teacher_id,completed=case when learning_blocks.teacher_id=excluded.teacher_id then learning_blocks.completed else false end;
end;$$;
create function public.manage_block(student uuid, block integer, action text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.owns_student(student) then raise exception 'Нет доступа';end if;
 if action='revoke' then delete from public.learning_blocks where student_id=student and module=block and teacher_id=auth.uid();
 elsif action in ('complete','reopen') then update public.learning_blocks set completed=(action='complete') where student_id=student and module=block and teacher_id=auth.uid();
 else raise exception 'Неизвестное действие';end if;
end;$$;
create function public.send_homework(selected_module integer, task_text text, solution_code text default '', solution_image text default '') returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.is_student() or not private.block_open(auth.uid(),selected_module) then raise exception 'Блок ещё не открыт';end if;
 insert into public.homework(student_id,module,statement,code,image) values(auth.uid(),selected_module,trim(task_text),coalesce(solution_code,''),coalesce(solution_image,''));
end;$$;
create function public.review_homework(homework_id uuid, decision text, comment text default '') returns void language plpgsql security definer set search_path='' as $$
declare h public.homework;
begin
 select * into h from public.homework where id=homework_id;
 if h.id is null or not private.owns_student(h.student_id) or decision not in ('accepted','revision') or decision is null then raise exception 'Нет доступа или неверный статус';end if;
 update public.homework set status=decision,feedback=coalesce(comment,'') where id=h.id;
 if decision='accepted' then update public.learning_blocks set completed=true where student_id=h.student_id and module=h.module and teacher_id=auth.uid();end if;
end;$$;
create function public.import_tasks(items jsonb) returns integer language plpgsql security definer set search_path='' as $$
declare item jsonb; count integer:=0;
begin
 if not private.is_teacher() then raise exception 'Нет доступа';end if;
 if jsonb_typeof(items)<>'array' or jsonb_array_length(items) not between 1 and 200 or length(items::text)>4000000 then raise exception 'Нужен массив от 1 до 200 задач, до 4 МБ';end if;
 for item in select value from jsonb_array_elements(items) loop
 if jsonb_typeof(item)<>'object' or coalesce(item->>'answer','')='' or coalesce(item->>'difficulty','Базовый') not in ('Базовый','Средний','Высокий') or length(coalesce(item->>'hint',''))>20000 or length(coalesce(item->>'solution',''))>50000 then raise exception 'Неверные поля задачи %',count+1;end if;
 perform public.save_task(jsonb_build_object('difficulty','Базовый')||item||jsonb_build_object('id',gen_random_uuid(),'published',false));
 count:=count+1;
 end loop;
 return count;
end;$$;
revoke all on function private.block_done(uuid,integer),private.block_open(uuid,integer) from public,anon,authenticated;
grant execute on function private.block_open(uuid,integer) to authenticated;
revoke all on function public.block_status(),public.assign_block(integer,uuid,uuid),public.manage_block(uuid,integer,text),public.send_homework(integer,text,text,text),public.review_homework(uuid,text,text),public.import_tasks(jsonb) from public,anon,authenticated;
grant execute on function public.block_status(),public.assign_block(integer,uuid,uuid),public.manage_block(uuid,integer,text),public.send_homework(integer,text,text,text),public.review_homework(uuid,text,text),public.import_tasks(jsonb) to authenticated;
commit;
