begin;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('theory-images','theory-images',false,10485760,array['image/jpeg','image/png','image/webp']) on conflict(id) do update set public=false,file_size_limit=10485760,allowed_mime_types=array['image/jpeg','image/png','image/webp'];
create table public.theory_images(
 id uuid primary key default gen_random_uuid(),
 block_id uuid not null references public.task_folders(id) on delete cascade,
 teacher_id uuid not null references public.profiles(id),
 object_path text not null unique,
 alt text not null default '' check(length(alt)<=255),
 created_at timestamptz not null default now(),
 check(object_path=teacher_id::text||'/'||block_id::text||'/'||id::text)
);
alter table public.theory_images enable row level security;
revoke all on public.theory_images from public,anon,authenticated;
grant select,insert,delete on public.theory_images to authenticated;
create policy theory_images_read on public.theory_images for select to authenticated using(private.can_open_study_block(block_id));
create policy theory_images_insert on public.theory_images for insert to authenticated with check(private.is_teacher() and teacher_id=auth.uid() and exists(select 1 from public.task_folders f where f.id=block_id and f.teacher_id=auth.uid()));
create policy theory_images_delete on public.theory_images for delete to authenticated using(private.is_teacher() and teacher_id=auth.uid());
create policy theory_objects_upload on storage.objects for insert to authenticated with check(bucket_id='theory-images' and private.is_teacher() and (storage.foldername(storage.objects.name))[1]=auth.uid()::text and exists(select 1 from public.task_folders f where f.id::text=(storage.foldername(storage.objects.name))[2] and f.teacher_id=auth.uid()));
create policy theory_objects_read on storage.objects for select to authenticated using(bucket_id='theory-images' and ((private.is_teacher() and (storage.foldername(storage.objects.name))[1]=auth.uid()::text) or exists(select 1 from public.theory_images f where f.object_path=name and private.can_open_study_block(f.block_id))));
create policy theory_objects_delete on storage.objects for delete to authenticated using(bucket_id='theory-images' and private.is_teacher() and (storage.foldername(storage.objects.name))[1]=auth.uid()::text);
commit;
