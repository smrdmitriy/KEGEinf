begin;
insert into storage.buckets(id,name,public,file_size_limit) values('task-files','task-files',false,20971520) on conflict(id) do update set public=false,file_size_limit=20971520;
create table public.task_files(
 id uuid primary key default gen_random_uuid(),
 task_id uuid not null references public.tasks(id) on delete cascade,
 teacher_id uuid not null references public.profiles(id),
 filename text not null check(length(trim(filename)) between 1 and 255),
 object_path text not null unique,
 size bigint not null check(size between 1 and 20971520),
 created_at timestamptz not null default now(),
 check(object_path=teacher_id::text||'/'||task_id::text||'/'||id::text)
);
alter table public.task_files enable row level security;
revoke all on public.task_files from public,anon,authenticated;
grant select,insert,delete on public.task_files to authenticated;
create policy task_files_read on public.task_files for select to authenticated using(private.can_read_task(task_id));
create policy task_files_insert on public.task_files for insert to authenticated with check(private.is_teacher() and teacher_id=auth.uid() and exists(select 1 from public.tasks t where t.id=task_id and t.teacher_id=auth.uid()));
create policy task_files_delete on public.task_files for delete to authenticated using(private.is_teacher() and teacher_id=auth.uid());
create policy task_objects_upload on storage.objects for insert to authenticated with check(bucket_id='task-files' and private.is_teacher() and (storage.foldername(name))[1]=auth.uid()::text and exists(select 1 from public.tasks t where t.id::text=(storage.foldername(name))[2] and t.teacher_id=auth.uid()));
create policy task_objects_read on storage.objects for select to authenticated using(bucket_id='task-files' and ((private.is_teacher() and (storage.foldername(name))[1]=auth.uid()::text) or exists(select 1 from public.task_files f where f.object_path=name and private.can_read_task(f.task_id))));
create policy task_objects_delete on storage.objects for delete to authenticated using(bucket_id='task-files' and private.is_teacher() and (storage.foldername(name))[1]=auth.uid()::text);
commit;
