begin;
create function public.save_student_profile(student uuid, first_name text,last_name text,school_class text,avatar text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.owns_student(student) or not exists(select 1 from public.profiles where id=student and role='student') then raise exception 'Ученик недоступен';end if;
 if first_name is null or length(trim(first_name)) not between 1 and 40 or last_name is null or length(trim(last_name))>40 or school_class is null or length(trim(school_class))>20 or avatar is null then raise exception 'Проверьте поля профиля';end if;
 update public.profiles p set first_name=trim(save_student_profile.first_name),last_name=trim(save_student_profile.last_name),school_class=trim(save_student_profile.school_class),avatar=save_student_profile.avatar,name=trim(trim(save_student_profile.last_name)||' '||trim(save_student_profile.first_name)) where p.id=student;
end;$$;
revoke all on function public.save_student_profile(uuid,text,text,text,text) from public,anon,authenticated;
grant execute on function public.save_student_profile(uuid,text,text,text,text) to authenticated;
commit;
