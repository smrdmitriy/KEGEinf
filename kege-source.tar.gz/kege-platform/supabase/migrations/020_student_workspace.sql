begin;
alter table public.study_block_members add column assigned_at timestamptz not null default now();
create or replace function public.assign_study_block(selected_block uuid,selected_student uuid default null,school_class text default null,selected_group uuid default null) returns integer language plpgsql security definer set search_path='' as $$
declare total integer;
begin
 if not private.is_teacher() or not exists(select 1 from public.task_folders where id=selected_block and teacher_id=auth.uid()) then raise exception 'Блок недоступен';end if;
 if num_nonnulls(selected_student,nullif(trim(school_class),''),selected_group)<>1 then raise exception 'Выберите одного получателя';end if;
 insert into public.study_block_members(block_id,student_id)
 select selected_block,e.student_id from public.enrollments e join public.profiles p on p.id=e.student_id where e.teacher_id=auth.uid() and (e.student_id=selected_student or p.school_class=nullif(trim(assign_study_block.school_class),'') or e.group_id=selected_group)
 on conflict(block_id,student_id) do update set assigned_at=clock_timestamp();
 get diagnostics total=row_count;return total;
end;$$;
create or replace function public.send_task_solution(selected_task uuid,selected_module integer,task_text text,solution_code text default '',solution_image text default '') returns void language plpgsql security definer set search_path='' as $$
begin
 if not private.is_student() or not private.can_read_task(selected_task) or not exists(select 1 from public.tasks where id=selected_task and module=selected_module) then raise exception 'Задача недоступна';end if;
 insert into public.homework(student_id,module,task_id,statement,code,image) select auth.uid(),module,id,title||E'\n'||statement,coalesce(solution_code,''),coalesce(solution_image,'') from public.tasks where id=selected_task;
end;$$;
create or replace function public.submit_answer(selected_task uuid,submitted_answer text,elapsed_seconds integer default 0) returns jsonb language plpgsql security definer set search_path='' as $$
 declare expected text; explanation text; is_correct boolean;
 begin
 if not private.is_student() then raise exception 'Войдите как ученик';end if;
 if not private.can_read_task(selected_task) or not exists(select 1 from public.tasks where id=selected_task and published) then raise exception 'Задача недоступна';end if;
 if length(trim(submitted_answer)) not between 1 and 500 then raise exception 'Введите ответ длиной от 1 до 500 символов';end if;
 select answer,solution into expected,explanation from private.task_keys where task_id=selected_task;
 if expected is null then raise exception 'Для задачи ещё не настроена проверка';end if;
 is_correct := lower(trim(submitted_answer))=lower(trim(expected));
 insert into public.attempts(student_id,task_id,answer,correct,duration) values(auth.uid(),selected_task,trim(submitted_answer),is_correct,greatest(0,least(coalesce(elapsed_seconds,0),86400)));
 return jsonb_build_object('correct',is_correct,'solution','');
 end;
$$;
create function public.student_last_block() returns uuid language sql stable security definer set search_path='' as $$
 select m.block_id from public.study_block_members m where m.student_id=auth.uid() and private.can_open_study_block(m.block_id) order by m.assigned_at desc,m.block_id limit 1;
$$;
revoke all on function public.student_last_block() from public,anon;
grant execute on function public.student_last_block() to authenticated;
create or replace function public.block_catalog() returns table(id uuid,name text,standard_number integer,can_open boolean,description text,icon text) language sql stable security definer set search_path='' as $$
 select f.id,f.name,f.standard_number,private.can_open_study_block(f.id),f.description,f.icon from public.task_folders f
 where f.teacher_id=case when private.is_teacher() then auth.uid() when auth.uid() is not null then private.own_teacher() else '6645f06d-3371-4695-b58a-c926222e6515'::uuid end
 and (auth.uid() is null or private.is_teacher() or private.can_open_study_block(f.id))
 order by f.standard_number nulls last,f.name;
$$;
do $$ begin
 if exists(select 1 from pg_publication where pubname='supabase_realtime') and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='study_block_members') then
 alter publication supabase_realtime add table public.study_block_members;
 end if;
end $$;
commit;
