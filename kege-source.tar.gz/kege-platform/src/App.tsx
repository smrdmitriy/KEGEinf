import { useEffect } from 'react';
import { Link, NavLink, Route, Routes, useLocation, useParams } from 'react-router-dom';
import { ArrowUpRight, BookOpen, Code2, GraduationCap, LayoutDashboard } from 'lucide-react';
import { Home } from './pages/Home';
import { Module } from './pages/Module';
import { Progress } from './pages/Account';
import { PasswordSetup } from './components/PasswordSetup';
import { usePlatform } from './context/Platform';
import {StudyBlocks} from './components/StudyBlocks';
import {RequireAuth} from './pages/Account';
import { Teacher } from './pages/Teacher';
export default function App() {
  const { profile } = usePlatform();
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return <><a href="#main" onClick={e => { e.preventDefault(); document.getElementById('main')?.focus(); }} className="skip-link">Перейти к содержимому</a><header className="header"><div className="header-inner"><Link to="/" className="brand" aria-label="КЕГЭ — главная"><span className="brand-icon"><Code2 size={23}/></span><strong>КЕГЭ<span className="brand-divider">/</span><span className="brand-sub">Информатика</span></strong></Link><nav aria-label="Основная навигация"><NavLink to="/" end><BookOpen size={17}/> Задания</NavLink><NavLink to="/progress"><LayoutDashboard size={17}/> Мой кабинет</NavLink></nav><Link to="/teacher" className="teacher-link" aria-label="Кабинет преподавателя"><GraduationCap size={18}/><span>Преподавателю</span><ArrowUpRight size={15}/></Link></div></header><main id="main" tabIndex={-1}>{profile?.role === 'student' && profile.must_change_password ? <PasswordSetup/> : <Routes><Route path="/" element={<Home/>}/><Route path="/module/:id" element={<Module/>}/><Route path="/progress" element={<Progress/>}/><Route path="/block/:id" element={<BlockPage/>}/><Route path="/teacher" element={<Teacher/>}/><Route path="*" element={<section className="container empty-page"><h1>Страница не найдена</h1><Link className="button primary" to="/">К заданиям</Link></section>}/></Routes>}</main><footer className="container footer"><Link to="/" className="footer-brand"><Code2 size={19}/> КЕГЭ <span>Информатика</span></Link><span>От понимания алгоритма — к уверенному решению.</span><span className="version">Учиться. Понимать. Получаться.</span></footer></>;
}
function BlockPage(){const {id}=useParams();const {profile}=usePlatform();return <RequireAuth><div className="container module-page"><StudyBlocks key={id} initialId={id} teacher={profile?.role==='teacher'}/></div></RequireAuth>;}
