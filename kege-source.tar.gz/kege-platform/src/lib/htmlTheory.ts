export const HTML_THEORY_LIMIT=2097152;
export function validateTheoryHtml(html:string){if(!html.trim())throw Error('HTML-документ пуст');if(new TextEncoder().encode(html).length>HTML_THEORY_LIMIT)throw Error('HTML-документ должен быть не больше 2 МБ');return html;}
// The frame has an opaque origin. The CSP is first, so document markup cannot relax it.
export function isolatedTheoryDocument(html:string){
 const policy="default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' https: blob:; style-src 'unsafe-inline' https:; img-src data: blob: https:; font-src data: https:; media-src data: blob: https:; connect-src 'none'; worker-src blob:; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'";
 return '<!doctype html><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="'+policy+'"><meta name="referrer" content="no-referrer">'+html;
}
