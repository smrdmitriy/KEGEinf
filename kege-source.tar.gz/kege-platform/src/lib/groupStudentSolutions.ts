import type {Homework,Task} from './types';
export function groupStudentSolutions(works:Homework[],tasks:Task[],blocks:{id:string;name:string;standard_number:number|null}[],studentId:string){
 const result=new Map<string,{id:string;name:string;order:number;tasks:Map<string,{id:string;title:string;works:Homework[]}>}>();
 for(const work of [...works].filter(w=>w.student_id===studentId).sort((a,b)=>b.created_at.localeCompare(a.created_at))){
  const task=tasks.find(t=>t.id===work.task_id);const block=blocks.find(b=>b.id===task?.folder_id);const blockId=block?.id||`archive:${work.module}`;
  if(!result.has(blockId))result.set(blockId,{id:blockId,name:block?.name||`Архив · задание №${work.module}`,order:block?.standard_number??100,tasks:new Map()});
  const group=result.get(blockId)!;const taskId=work.task_id||`work:${work.id}`;
  if(!group.tasks.has(taskId))group.tasks.set(taskId,{id:taskId,title:task?.title||work.statement.split('\n')[0]||'Решение задачи',works:[]});
  group.tasks.get(taskId)!.works.push(work);
 }
 return [...result.values()].sort((a,b)=>a.order-b.order||a.name.localeCompare(b.name,'ru')).map(block=>({...block,tasks:[...block.tasks.values()]}));
}
