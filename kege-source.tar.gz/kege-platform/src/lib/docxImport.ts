import { unzipSync, zipSync, strFromU8, strToU8 } from 'fflate';

export type ImportedTask = {module:number;title:string;statement:string;answer:string;difficulty:string;hint:string;solution:string};
const W='http://schemas.openxmlformats.org/wordprocessingml/2006/main';
const labels: Record<string,keyof ImportedTask>={'номер':'module','номер кегэ':'module','название':'title','условие':'statement','ответ':'answer','правильный ответ':'answer','сложность':'difficulty','подсказка':'hint','решение':'solution','подробное решение':'solution'};
export function parseTaskText(text:string,defaultModule:number):ImportedTask[]{
  const rows=text.replace(/\r\n?/g,'\n').split('\n');const result:ImportedTask[]=[];
  let task:Record<string,string>|null=null,field:string|null=null;
  function finish(){if(!task)return;const n=result.length+1;const m=task.module===undefined?defaultModule:Number(task.module.trim());
    if(!Number.isInteger(m)||m<1||m>27)throw new Error(`Задача ${n}: номер КЕГЭ должен быть от 1 до 27.`);
    for(const [key,title,max] of [['title','Название',150],['statement','Условие',20000],['answer','Ответ',500]] as const)if(!task[key]?.trim()||task[key].trim().length>max)throw new Error(`Задача ${n}: заполните «${title}» (до ${max} символов).`);
    for(const [key,max] of [['hint',20000],['solution',50000]] as const)if((task[key]?.length||0)>max)throw new Error(`Задача ${n}: поле ${key} слишком длинное.`);
    const difficulty=task.difficulty?.trim()||'Базовый';if(!['Базовый','Средний','Высокий'].includes(difficulty))throw new Error(`Задача ${n}: сложность — Базовый, Средний или Высокий.`);
    result.push({module:m,title:task.title.trim(),statement:task.statement.trim(),answer:task.answer.trim(),difficulty,hint:task.hint?.trim()||'',solution:task.solution?.trim()||''});
    if(result.length>200)throw new Error('В одном файле допускается не более 200 задач.');
  }
  for(const row of rows){if(/^\s*Задача\s+(?:№\s*)?\d+\s*\.?\s*$/i.test(row)){finish();task={};field=null;continue;}if(!task)continue;
    const match=row.match(/^\s*([^:]+):\s*(.*)$/);const key=match?labels[match[1].trim().toLocaleLowerCase('ru')]:undefined;
    if(key){if(Object.hasOwn(task,key))throw new Error(`Задача ${result.length+1}: поле «${match![1]}» повторяется. Между задачами нужен заголовок «Задача 2».`);field=key;task[key]=match![2];}
    else if(field){task[field]+='\n'+row;}else if(row.trim())throw new Error(`Задача ${result.length+1}: начните с поля «Название:».`);
  }finish();if(!result.length)throw new Error('Задачи не найдены. Используйте шаблон: каждый блок начинается с «Задача 1», «Задача 2» и т. д.');
  if(new TextEncoder().encode(JSON.stringify(result)).length>4000000)throw new Error('Текст задач превышает 4 МБ. Разделите документ.');return result;
}
export function readDocx(bytes:Uint8Array,defaultModule:number):ImportedTask[]{
  if(bytes.length>4000000)throw new Error('Файл должен быть не больше 4 МБ.');
  let files:Record<string,Uint8Array>;
  try {files=unzipSync(bytes,{filter:entry=>{if(!['word/document.xml','[Content_Types].xml'].includes(entry.name))return false;if(entry.originalSize>8000000)throw new Error('XML too large');return true;}});}catch{throw new Error('Не удалось прочитать DOCX: файл повреждён, защищён паролем или слишком большой.');}
  if(!files['word/document.xml']||!files['[Content_Types].xml'])throw new Error('Нужен документ Word в формате .docx.');
  const xml=strFromU8(files['word/document.xml']);
  if(/<!DOCTYPE|<!ENTITY/i.test(xml))throw new Error('Этот документ содержит неподдерживаемую XML-разметку.');
  const doc=new DOMParser().parseFromString(xml,'application/xml');
  if(doc.getElementsByTagName('parsererror').length||!doc.getElementsByTagNameNS(W,'body').length)throw new Error('Повреждена структура документа Word.');
  if(['drawing','pict','object','tbl','del','ins','altChunk','footnoteReference','endnoteReference'].some(name=>doc.getElementsByTagNameNS(W,name).length)||doc.getElementsByTagNameNS('http://schemas.openxmlformats.org/officeDocument/2006/math','oMath').length)throw new Error('Используйте текстовые абзацы шаблона. Таблицы, картинки, формулы Word, сноски и исправления пока не импортируются. Запишите формулы текстом и примите исправления.');
  function content(node:Node):string{if(node.nodeType===1){const el=node as Element;if(el.namespaceURI===W){if(el.localName==='t')return el.textContent||'';if(el.localName==='br'||el.localName==='cr')return '\n';if(el.localName==='tab')return '\t';}}return Array.from(node.childNodes).map(content).join('');}
  const paragraphs=Array.from(doc.getElementsByTagNameNS(W,'body')[0].getElementsByTagNameNS(W,'p')).map(content);
  return parseTaskText(paragraphs.join('\n'),defaultModule);
}
export function docxTemplate(module:number):Uint8Array{
  const lines=['Шаблон импорта задач КЕГЭ','Заполните поля и загрузите документ в папке банка задач. Каждый блок начинается с заголовка Задача и порядкового номера. Условие и решение могут занимать несколько абзацев. Не используйте таблицы, изображения или формулы Word.','Задача 1',`Номер КЕГЭ: ${module}`,'Название: Пример задачи','Условие: Сколько получится при сложении 20 и 22?','Ответ: 42','Сложность: Базовый','Подсказка: Сложите два числа.','Решение: 20 + 22 = 42.','Задача 2',`Номер КЕГЭ: ${module}`,'Название: Вторая задача','Условие: Чему равно 6 × 7?','Ответ: 42','Сложность: Средний','Подсказка: Используйте умножение.','Решение: 6 × 7 = 42.'];
  const escape=(s:string)=>s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const paragraphs=lines.map((line,i)=>`<w:p><w:pPr><w:spacing w:after="160"/>${i===0?'<w:pStyle w:val="Title"/>':''}</w:pPr><w:r><w:rPr>${i===0?'<w:b/><w:sz w:val="32"/>':'<w:sz w:val="24"/>'}</w:rPr><w:t xml:space="preserve">${escape(line)}</w:t></w:r></w:p>`).join('');
  return zipSync({'[Content_Types].xml':strToU8('<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'),'_rels/.rels':strToU8('<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'),'word/document.xml':strToU8(`<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="${W}"><w:body>${paragraphs}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134"/></w:sectPr></w:body></w:document>`)},{level:6});
}
