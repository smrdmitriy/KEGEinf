import type {Attempt,Homework} from './types';
export type StudentTaskStatus='unanswered'|'incorrect'|'answer-only'|'complete'|'revision';
export function studentTaskStatus(attempts:Attempt[],works:Homework[],taskId:string,studentId:string):StudentTaskStatus{
 let latest:Attempt|undefined;
 for(const attempt of attempts){
  if(attempt.task_id!==taskId||attempt.student_id!==studentId)continue;
  if(!latest||attempt.created_at>latest.created_at)latest=attempt;
 }
 const latestWork=works.filter(work=>work.task_id===taskId&&work.student_id===studentId).reduce<Homework|undefined>((previous,work)=>!previous||work.created_at>previous.created_at?work:previous,undefined);
 if(latestWork?.status==='revision')return 'revision';
 if(!latest)return 'unanswered';
 if(!latest.correct)return 'incorrect';
 const attached=works.some(work=>work.task_id===taskId&&work.student_id===studentId&&(work.code.trim().length>0||work.image.length>0));
 return attached?'complete':'answer-only';
}
