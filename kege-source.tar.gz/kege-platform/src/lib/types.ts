export type Profile = { id: string; name: string; email: string; role: 'student' | 'teacher'; superuser?: boolean; must_change_password?: boolean; first_name?: string; last_name?: string; school_class?: string; avatar?: string };
export type Group = { id: string; name: string };
export type Student = Profile & { group_id: string | null };
export type Task = { work_type?: 'classwork' | 'homework'; images?: string[]; id: string; module: number; title: string; statement: string; difficulty: string; hint: string; published: boolean; teacher_id: string | null; answer?: string; solution?: string };
export type Attempt = { id: string; student_id: string; task_id: string; answer: string; correct: boolean; duration: number; created_at: string };
export type Assignment = { id: string; task_id: string; student_id: string | null; group_id: string | null; due_date: string | null };
export type Slide = { student_id: string; module: number; slide: number };
export type Data = { students: Student[]; groups: Group[]; tasks: Task[]; attempts: Attempt[]; assignments: Assignment[]; slides: Slide[]; homeworkBlocks: (LearningBlock & {due_date: string | null})[]; blocks: LearningBlock[]; blockStatus: BlockStatus[]; homework: Homework[] };

export type LearningBlock = {student_id:string; teacher_id:string; module:number; completed:boolean};
export type BlockStatus = {module:number; unlocked:boolean; completed:boolean};
export type Homework = {task_id?:string|null;id:string; student_id:string; module:number; statement:string; code:string; image:string; status:"pending"|"accepted"|"revision"; feedback:string; created_at:string};
