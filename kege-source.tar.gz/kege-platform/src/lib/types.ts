export type Profile = { id: string; name: string; email: string; role: 'student' | 'teacher' };
export type Group = { id: string; name: string };
export type Student = Profile & { group_id: string | null };
export type Task = { id: string; module: number; title: string; statement: string; difficulty: string; hint: string; published: boolean; teacher_id: string | null; answer?: string; solution?: string };
export type Attempt = { id: string; student_id: string; task_id: string; answer: string; correct: boolean; duration: number; created_at: string };
export type Assignment = { id: string; task_id: string; student_id: string | null; group_id: string | null; due_date: string | null };
export type Slide = { student_id: string; module: number; slide: number };
export type Data = { students: Student[]; groups: Group[]; tasks: Task[]; attempts: Attempt[]; assignments: Assignment[]; slides: Slide[] };
