import type {Homework} from './types';
// Count tasks with saved attachments, rather than repeated submissions.
export function attachedTaskIds(works:Homework[],studentId:string){
 return new Set(works.filter(work=>work.student_id===studentId&&work.task_id&&(work.code.trim()||work.image)).map(work=>work.task_id!));
}
