export function solutionFileKind(file:Pick<File,'name'|'type'|'size'>):'image'|'code'{
 if(['image/jpeg','image/png','image/webp'].includes(file.type)){
  if(file.size>10000000)throw Error('Изображение должно быть не больше 10 МБ');
  return 'image';
 }
 if(/\.(py|txt)$/i.test(file.name)){
  if(file.size>100000)throw Error('Файл кода должен быть не больше 100 КБ');
  return 'code';
 }
 throw Error('Прикрепите JPG, PNG, WebP или файл кода .py, .txt');
}
