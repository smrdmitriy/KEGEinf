import {ProfileAvatar} from '../components/ProfileAvatar';
import {StudentOverview} from '../components/StudentOverview';
import {TeacherOverview} from '../components/TeacherOverview';
import { StudyBlocks } from '../components/StudyBlocks';
import { useState, type ReactNode, type FormEvent } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { BookOpen, GraduationCap, LayoutDashboard, LogOut, Users } from 'lucide-react';
import { usePlatform } from '../context/Platform';
import { ProfileSettings } from './ProfileSettings';
export function AccountShell({ teacher = false, children }: { teacher?: boolean; children: ReactNode }) {
  const { profile, loading, error, logout } = usePlatform();
  const [logoutError, setLogoutError] = useState('');
  const [editing, setEditing] = useState(false);
  if (loading) return <section className="container empty-page" role="status">Загружаем кабинет…</section>;
  if (!profile) return <Auth />;
  if (teacher && profile.role !== 'teacher') return <section className="container empty-page"><GraduationCap size={40}/><h1>Кабинет преподавателя</h1><p>Эта страница доступна только преподавателю. Роль назначает администратор платформы.</p><Link to="/progress" className="button secondary">Мой кабинет</Link></section>;
  return <div className="workspace container"><aside className="account-sidebar"><ProfileAvatar id={profile.id} name={profile.name} avatar={profile.avatar}/><strong>{profile.name}</strong><span>{profile.superuser ? 'Суперпользователь' : profile.role === 'teacher' ? 'Преподаватель' : 'Ученик'}</span>{profile.role==='student'&&<><span>Класс · {profile.school_class||'Не указан'}</span></>}<button className="text-button" onClick={()=>setEditing(!editing)}>{editing ? 'Вернуться в кабинет' : 'Редактировать профиль'}</button><div className="sidebar-links"><NavLink to="/progress"><LayoutDashboard size={19}/> Мой кабинет</NavLink>{profile.role === 'teacher' && <NavLink to="/teacher"><Users size={19}/> Преподавателю</NavLink>}{profile.role==='teacher'&&<NavLink to="/"><BookOpen size={19}/> Все задания</NavLink>}</div><div className="sidebar-bottom"><span className="connection"><i/>Supabase подключён</span><p>Прогресс синхронизируется с вашей учётной записью.</p><button className="text-button" onClick={() => { logout().catch(e => setLogoutError(e.message)); }}><LogOut size={16}/> Выйти</button></div></aside><section className="account-content">{(error || logoutError) && <p role="alert" className="alert error">{error || logoutError}</p>}{editing ? <ProfileSettings onClose={()=>setEditing(false)}/> : children}</section></div>;
}
export function Auth() {
  const { local, login, error } = usePlatform();
  const [message, setMessage] = useState(''), [busy, setBusy] = useState(false);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); const form = new FormData(e.currentTarget); setBusy(true); setMessage('');
    try { await login(String(form.get('email')), String(form.get('password'))); }
    catch(e) { setMessage(e instanceof Error ? e.message : 'Не удалось войти'); }
    finally { setBusy(false); }
  }
  return <div className="auth-card glass"><span className="large-icon"><GraduationCap size={34}/></span><span className="eyebrow">ДОСТУП ПО ПРИГЛАШЕНИЮ</span><h1>Войдите, чтобы продолжить</h1><p>Учётную запись создаёт преподаватель. Используйте почту и временный пароль, которые он вам выдал.</p>{local ? <p className="alert" role="status">Подключение базы данных ещё не завершено. Вход будет доступен после настройки Supabase администратором.</p> : <form onSubmit={submit}><label>Почта<input name="email" type="email" required autoComplete="username"/></label><label>Пароль<input name="password" type="password" required autoComplete="current-password"/></label><button disabled={busy} className="button primary">{busy ? 'Входим…' : 'Войти'}</button></form>}{(message || error) && <p role="alert" className="alert error">{message || error}</p>}<p className="auth-note">Нет доступа или забыли пароль? Обратитесь к своему преподавателю.</p><Link to="/" className="text-button">Вернуться к заданиям</Link></div>;
}
export function RequireAuth({ children }: { children: ReactNode }) {
  const { profile, loading } = usePlatform();
  if (loading) return <section className="container empty-page" role="status">Проверяем доступ…</section>;
  return profile ? <>{children}</> : <Auth/>;
}
export function Progress(){
 const {profile}=usePlatform();
 return <AccountShell>{profile?.role==='teacher'?<TeacherOverview/>:<><StudentOverview/><StudyBlocks/></>}</AccountShell>;
}
export function Stat({icon,label,value,note}:{icon:ReactNode;label:string;value:string;note:string}) { return <div className="stat-card"><span className="stat-icon">{icon}</span><span>{label}</span><strong>{value}</strong><small>{note}</small></div>; }
