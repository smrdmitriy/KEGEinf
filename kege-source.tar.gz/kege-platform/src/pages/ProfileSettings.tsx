import { useState, useRef, type FormEvent } from 'react';
import { usePlatform } from '../context/Platform';

export function ProfileSettings({ onClose }: { onClose: () => void }) {
  const { profile, saveProfile } = usePlatform();
  const [first, setFirst] = useState(profile?.first_name || profile?.name || '');
  const [last, setLast] = useState(profile?.last_name || '');
  const [schoolClass, setClass] = useState(profile?.school_class || '');
  const [avatar, setAvatar] = useState(profile?.avatar || '');
  const [busy, setBusy] = useState(false), [imageBusy, setImageBusy] = useState(false), [message, setMessage] = useState('');
  const imageRevision = useRef(0);
  async function upload(file?: File) {
    const revision = ++imageRevision.current;
    if (!file) return;
    setMessage(''); setImageBusy(true);
    try {
      if (!['image/jpeg','image/png','image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024) throw new Error('Выберите JPG, PNG или WebP до 5 МБ.');
      const bitmap = await createImageBitmap(file);
      try {
        const canvas = document.createElement('canvas'); canvas.width = canvas.height = 256;
        const ctx = canvas.getContext('2d'); if (!ctx) throw new Error('Не удалось обработать фото.');
        const size = Math.min(bitmap.width, bitmap.height);
        ctx.fillStyle = '#ffffff'; ctx.fillRect(0,0,256,256);
        ctx.drawImage(bitmap,(bitmap.width-size)/2,(bitmap.height-size)/2,size,size,0,0,256,256);
        const result = canvas.toDataURL('image/jpeg',0.8);
        if (result.length > 120000) throw new Error('Фото слишком большое. Выберите другое изображение.');
        if (revision === imageRevision.current) setAvatar(result);
      } finally { bitmap.close(); }
    } catch(e) { if(revision===imageRevision.current) setMessage(e instanceof Error ? e.message : 'Не удалось открыть изображение.'); }
    finally { if(revision===imageRevision.current) setImageBusy(false); }
  }
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMessage('');
    try { await saveProfile({first_name:first.trim(),last_name:last.trim(),school_class:schoolClass.trim(),avatar}); setMessage('Профиль сохранён'); }
    catch(e) { setMessage(e instanceof Error ? e.message : 'Не удалось сохранить профиль'); }
    finally { setBusy(false); }
  }
  return <section className="panel"><div className="page-heading"><div><span className="eyebrow">ЛИЧНЫЕ ДАННЫЕ</span><h1>Ваш профиль</h1><p>Так вас видит преподаватель в списке учеников.</p></div></div><form className="form-grid" onSubmit={submit}><div className="span-full avatar-editor"><div className="profile-avatar">{avatar ? <img src={avatar} alt="Предпросмотр аватара"/> : (first[0] || '?').toUpperCase()}</div><div><label>Изменить аватар<input type="file" accept="image/jpeg,image/png,image/webp" disabled={busy||imageBusy} onChange={e=>{void upload(e.target.files?.[0]);e.target.value='';}}/></label><small>JPG, PNG или WebP до 5 МБ. Фото обрезается по центру.</small>{avatar && <button type="button" className="text-button" disabled={busy||imageBusy} onClick={()=>setAvatar('')}>Удалить фото</button>}</div></div><label>Фамилия<input autoComplete="family-name" value={last} maxLength={40} onChange={e=>setLast(e.target.value)} disabled={busy}/></label><label>Имя<input required autoComplete="given-name" value={first} maxLength={40} onChange={e=>setFirst(e.target.value)} disabled={busy}/></label>{profile?.role==='student' && <label>Класс<input placeholder="Например, 11А" maxLength={20} value={schoolClass} onChange={e=>setClass(e.target.value)} disabled={busy}/></label>}<label>Роль<input readOnly value={profile?.role==='teacher'?'Преподаватель':'Ученик'}/><small>Роль доступа назначает администратор платформы.</small></label><label className="span-full">Почта<input readOnly value={profile?.email || ''}/></label><div className="form-actions span-full"><button className="button primary" disabled={busy||imageBusy}>{busy?'Сохраняем…':imageBusy?'Обрабатываем фото…':'Сохранить изменения'}</button><button className="button secondary" type="button" disabled={busy} onClick={onClose}>В кабинет</button></div>{message && <p role="status" className="alert span-full">{message}</p>}</form></section>;
}
