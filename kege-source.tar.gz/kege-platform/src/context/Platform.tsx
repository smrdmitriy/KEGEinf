import { createContext, useContext, useEffect, useState, useRef, type ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import type { Assignment, Data, Profile, Task } from '../lib/types';
const empty: Data = { students: [], groups: [], tasks: [], attempts: [], assignments: [], slides: [] };
function check(error: { message: string } | null) { if (error) throw new Error(error.message); }
interface PlatformValue {
  data: Data; profile: Profile | null; loading: boolean; error: string; local: boolean;
  login: (email: string, password: string) => Promise<string>;
  logout: () => Promise<void>; refresh: () => Promise<void>;
  addStudent: (name: string, email: string, group: string) => Promise<{ email: string; password: string }>;
  updateStudent: (id: string, group: string) => Promise<void>; removeStudent: (id: string) => Promise<void>;
  addGroup: (name: string) => Promise<void>; removeGroup: (id: string) => Promise<void>;
  saveTask: (task: Task) => Promise<void>; removeTask: (id: string) => Promise<void>;
  assign: (assignment: Omit<Assignment, 'id'>) => Promise<void>; removeAssignment: (id: string) => Promise<void>;
  submit: (taskId: string, answer: string, duration: number) => Promise<{ correct: boolean; solution: string }>;
  markSlide: (module: number, slide: number) => Promise<void>;
}
const Context = createContext<PlatformValue | null>(null);
export function PlatformProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<Data>(empty);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(!!supabase);
  const [error, setError] = useState('');
  const revision = useRef(0);
  async function refresh() {
    if (!supabase) return;
    const request = ++revision.current;
    const { data: auth } = await supabase.auth.getSession();
    if (request !== revision.current) return;
    if (!auth.session) { setProfile(null); setData(empty); return; }
    const me = await supabase.from('profiles').select('*').eq('id', auth.session.user.id).maybeSingle(); check(me.error);
    if (!me.data) { setProfile(null); setData(empty); throw new Error('Доступ пока не выдан или закрыт. Обратитесь к преподавателю.'); }
    if (request !== revision.current) return;
    if (me.data.role === 'student') {
      const membership = await supabase.from('enrollments').select('student_id').eq('student_id', auth.session.user.id).maybeSingle();
      check(membership.error);
      if (!membership.data) { setProfile(null); setData(empty); throw new Error('Доступ пока не выдан или закрыт. Обратитесь к преподавателю.'); }
    }
    if (request !== revision.current) return;
    const results = await Promise.all(['profiles', 'groups', 'tasks', 'attempts', 'assignments', 'slides', 'enrollments'].map(table => supabase!.from(table).select('*')));
    if (request !== revision.current) return;
    results.forEach(r => check(r.error));
    setProfile(me.data as Profile);
    setError('');
    const [people, groups, tasks, attempts, assignments, slides, enrollments] = results.map(r => r.data || []);
    setData({ students: people.filter(p => p.role === 'student').map(p => ({ ...p, group_id: enrollments.find(e => e.student_id === p.id)?.group_id || null })) as Data['students'], groups: groups as Data['groups'], tasks: tasks as Task[], attempts: attempts as Data['attempts'], assignments: assignments as Assignment[], slides: slides as Data['slides'] });
  }
  useEffect(() => {
    if (!supabase) return;
    let alive = true;
    const update = () => { if (!alive) return; setLoading(true); refresh().catch(e => { if(alive) { setProfile(null); setData(empty); setError(e.message); } }).finally(() => { if(alive) setLoading(false); }); };
    update();
    const { data: subscription } = supabase.auth.onAuthStateChange(() => { setTimeout(update, 0); });
    const recheck = () => { refresh().catch(e => { if (alive) { setProfile(null); setData(empty); setError(e.message); } }); };
    window.addEventListener('focus', recheck);
    const timer = window.setInterval(recheck, 60000);
    return () => { alive = false; revision.current++; window.clearInterval(timer); window.removeEventListener('focus', recheck); subscription.subscription.unsubscribe(); };
  }, []);
  const cloudMutation = async (operation: PromiseLike<{ error: { message: string } | null }>) => { const result = await operation; check(result.error); await refresh(); };
  const requireTeacher = () => { if (profile?.role !== 'teacher') throw new Error('Нужна учётная запись преподавателя.'); };
  const value: PlatformValue = {
    data, profile, loading, error, local: !supabase,
    refresh,
    async login(email, password) {
      if (!supabase) throw new Error('База данных пока не подключена.');
      const result = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (result.error) throw new Error('Не удалось войти. Проверьте почту и пароль, выданные преподавателем.');
      await refresh(); return '';
    },
    async logout() { if (supabase) { const result = await supabase.auth.signOut(); check(result.error); } revision.current++; setProfile(null); setData(empty); setError(''); },
    async addStudent(name, email, group) {
      requireTeacher();
      if (!supabase) throw new Error('База данных не подключена.');
      const result = await supabase.functions.invoke('create-student', { body: { name, email, group_id: group || null } });
      if (result.error) {
        let message = 'Не удалось создать ученика. Проверьте подключение серверной функции.';
        try { const body = await result.error.context?.json(); if (body?.error) message = body.error; } catch { /* Network errors have no JSON response. */ }
        throw new Error(message);
      }
      if (!result.data?.password || !result.data?.email) throw new Error('Сервер не вернул данные входа. Обратитесь к администратору.');
      // Return credentials before refreshing: a refresh failure must not lose the one-time password.
      return { email: result.data.email, password: result.data.password };
    },
    async updateStudent(id, group) { requireTeacher(); if (supabase) return cloudMutation(supabase.from('enrollments').update({ group_id: group || null }).eq('student_id', id)); throw new Error('База данных не подключена.'); },
    async removeStudent(id) { requireTeacher(); if (supabase) return cloudMutation(supabase.from('enrollments').delete().eq('student_id', id)); throw new Error('База данных не подключена.'); },
    async addGroup(name) { requireTeacher(); if (data.groups.some(g => g.name.toLowerCase() === name.toLowerCase())) throw new Error('Такая группа уже есть.'); if (supabase) return cloudMutation(supabase.from('groups').insert({ name, teacher_id: profile!.id })); throw new Error('База данных не подключена.'); },
    async removeGroup(id) { requireTeacher(); if (supabase) return cloudMutation(supabase.from('groups').delete().eq('id', id)); throw new Error('База данных не подключена.'); },
    async saveTask(task) { requireTeacher(); if (supabase) return cloudMutation(supabase.rpc('save_task', { task_data: task })); throw new Error('База данных не подключена.'); },
    async removeTask(id) { requireTeacher(); if (supabase) return cloudMutation(supabase.from('tasks').delete().eq('id', id)); throw new Error('База данных не подключена.'); },
    async assign(assignment) { requireTeacher(); if (supabase) return cloudMutation(supabase.from('assignments').insert({ ...assignment, teacher_id: profile!.id })); throw new Error('База данных не подключена.'); },
    async removeAssignment(id) { requireTeacher(); if (supabase) return cloudMutation(supabase.from('assignments').delete().eq('id', id)); throw new Error('База данных не подключена.'); },
    async submit(taskId, answer, duration) {
      if (profile?.role !== 'student') throw new Error('Войдите как ученик, чтобы сохранить попытку.');
      if (supabase) { const result = await supabase.rpc('submit_answer', { selected_task: taskId, submitted_answer: answer, elapsed_seconds: duration }); check(result.error); await refresh(); return result.data as { correct: boolean; solution: string }; }
      throw new Error('База данных не подключена.');
    },
    async markSlide(module, slide) {
      if (profile?.role !== 'student') throw new Error('Для сохранения теории войдите как ученик.');
      if (supabase) return cloudMutation(supabase.from('slides').upsert({ student_id: profile.id, module, slide }, { onConflict: 'student_id,module,slide' }));
    },
  };
  return <Context.Provider value={value}>{children}</Context.Provider>;
}
export function usePlatform() { const value = useContext(Context); if (!value) throw new Error('PlatformProvider missing'); return value; }
