import { createContext, useContext, useEffect, useState, useRef, type ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { demoStudent, demoTeacher, initialData } from '../data/demo';
import type { Assignment, Data, Profile, Task } from '../lib/types';
const storageKey = 'kege-local-v2';
const empty: Data = { students: [], groups: [], tasks: [], attempts: [], assignments: [], slides: [] };
function loadLocal(): Data { try { const value = JSON.parse(localStorage.getItem(storageKey) || 'null'); return value?.tasks && value?.students && value?.slides && value?.attempts && value?.groups && value?.assignments ? value : structuredClone(initialData); } catch { return structuredClone(initialData); } }
function check(error: { message: string } | null) { if (error) throw new Error(error.message); }
interface PlatformValue {
  data: Data; profile: Profile | null; loading: boolean; error: string; local: boolean;
  switchDemo: (role: 'student' | 'teacher') => void;
  login: (email: string, password: string, name?: string) => Promise<string>;
  logout: () => Promise<void>; refresh: () => Promise<void>;
  addStudent: (name: string, email: string, group: string) => Promise<void>;
  updateStudent: (id: string, group: string) => Promise<void>; removeStudent: (id: string) => Promise<void>;
  addGroup: (name: string) => Promise<void>; removeGroup: (id: string) => Promise<void>;
  saveTask: (task: Task) => Promise<void>; removeTask: (id: string) => Promise<void>;
  assign: (assignment: Omit<Assignment, 'id'>) => Promise<void>; removeAssignment: (id: string) => Promise<void>;
  submit: (taskId: string, answer: string, duration: number) => Promise<{ correct: boolean; solution: string }>;
  markSlide: (module: number, slide: number) => Promise<void>;
}
const Context = createContext<PlatformValue | null>(null);
export function PlatformProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<Data>(() => supabase ? empty : loadLocal());
  const [profile, setProfile] = useState<Profile | null>(supabase ? null : demoStudent);
  const [loading, setLoading] = useState(!!supabase);
  const [error, setError] = useState('');
  const revision = useRef(0);
  useEffect(() => { if (supabase) return; const update = (event: StorageEvent) => { if(event.key === storageKey) setData(loadLocal()); }; window.addEventListener('storage', update); return () => window.removeEventListener('storage', update); }, []);
  const persist = (change: (previous: Data) => Data) => setData(previous => { const next = change(previous); try { localStorage.setItem(storageKey, JSON.stringify(next)); } catch { setError('Браузер не разрешил сохранить данные. Изменения доступны только до обновления страницы.'); } return next; });
  async function refresh() {
    if (!supabase) return;
    const request = ++revision.current;
    const { data: auth } = await supabase.auth.getSession();
    if (request !== revision.current) return;
    if (!auth.session) { setProfile(null); setData(empty); return; }
    const me = await supabase.from('profiles').select('*').eq('id', auth.session.user.id).single(); check(me.error);
    if (request !== revision.current) return;
    setProfile(me.data as Profile);
    const results = await Promise.all(['profiles', 'groups', 'tasks', 'attempts', 'assignments', 'slides', 'enrollments'].map(table => supabase!.from(table).select('*')));
    if (request !== revision.current) return;
    results.forEach(r => check(r.error));
    setError('');
    const [people, groups, tasks, attempts, assignments, slides, enrollments] = results.map(r => r.data || []);
    setData({ students: people.filter(p => p.role === 'student').map(p => ({ ...p, group_id: enrollments.find(e => e.student_id === p.id)?.group_id || null })) as Data['students'], groups: groups as Data['groups'], tasks: tasks as Task[], attempts: attempts as Data['attempts'], assignments: assignments as Assignment[], slides: slides as Data['slides'] });
  }
  useEffect(() => {
    if (!supabase) return;
    let alive = true;
    const update = () => { if (!alive) return; setLoading(true); refresh().catch(e => { if(alive) setError(e.message); }).finally(() => { if(alive) setLoading(false); }); };
    update();
    const { data: subscription } = supabase.auth.onAuthStateChange(() => { setTimeout(update, 0); });
    return () => { alive = false; subscription.subscription.unsubscribe(); };
  }, []);
  const cloudMutation = async (operation: PromiseLike<{ error: { message: string } | null }>) => { const result = await operation; check(result.error); await refresh(); };
  const requireTeacher = () => { if (profile?.role !== 'teacher') throw new Error('Нужна учётная запись преподавателя.'); };
  const value: PlatformValue = {
    data, profile, loading, error, local: !supabase,
    switchDemo: role => { if (!supabase) setProfile(role === 'teacher' ? demoTeacher : demoStudent); },
    refresh,
    async login(email, password, name) {
      if (!supabase) return '';
      if (name) { const result = await supabase.auth.signUp({ email, password, options: { data: { name } } }); check(result.error); return result.data.session ? '' : 'Проверьте почту и подтвердите регистрацию, затем войдите.'; }
      const result = await supabase.auth.signInWithPassword({ email, password }); check(result.error); await refresh(); return '';
    },
    async logout() { if (supabase) { const result = await supabase.auth.signOut(); check(result.error); revision.current++; setProfile(null); setData(empty); } else setProfile(null); },
    async addStudent(name, email, group) {
      requireTeacher();
      if (supabase) return cloudMutation(supabase.rpc('enroll_student', { student_email: email, selected_group: group || null }));
      if (data.students.some(s => s.email.toLowerCase() === email.toLowerCase())) throw new Error('Ученик с этой почтой уже добавлен.');
      persist(d => ({ ...d, students: [...d.students, { id: crypto.randomUUID(), name, email, group_id: group || null, role: 'student' }] }));
    },
    async updateStudent(id, group) { requireTeacher(); if (supabase) return cloudMutation(supabase.from('enrollments').update({ group_id: group || null }).eq('student_id', id)); persist(d => ({ ...d, students: d.students.map(s => s.id === id ? { ...s, group_id: group || null } : s) })); },
    async removeStudent(id) { requireTeacher(); if (supabase) return cloudMutation(supabase.from('enrollments').delete().eq('student_id', id)); persist(d => ({ ...d, students: d.students.filter(s => s.id !== id), assignments: d.assignments.filter(a => a.student_id !== id) })); },
    async addGroup(name) { requireTeacher(); if (data.groups.some(g => g.name.toLowerCase() === name.toLowerCase())) throw new Error('Такая группа уже есть.'); if (supabase) return cloudMutation(supabase.from('groups').insert({ name, teacher_id: profile!.id })); persist(d => ({ ...d, groups: [...d.groups, { id: crypto.randomUUID(), name }] })); },
    async removeGroup(id) { requireTeacher(); if (supabase) return cloudMutation(supabase.from('groups').delete().eq('id', id)); persist(d => ({ ...d, groups: d.groups.filter(g => g.id !== id), students: d.students.map(s => s.group_id === id ? { ...s, group_id: null } : s), assignments: d.assignments.filter(a => a.group_id !== id) })); },
    async saveTask(task) { requireTeacher(); if (supabase) return cloudMutation(supabase.rpc('save_task', { task_data: task })); persist(d => ({ ...d, tasks: d.tasks.some(t => t.id === task.id) ? d.tasks.map(t => t.id === task.id ? task : t) : [...d.tasks, task] })); },
    async removeTask(id) { requireTeacher(); if (supabase) return cloudMutation(supabase.from('tasks').delete().eq('id', id)); persist(d => ({ ...d, tasks: d.tasks.filter(t => t.id !== id), assignments: d.assignments.filter(a => a.task_id !== id), attempts: d.attempts.filter(a => a.task_id !== id) })); },
    async assign(assignment) { requireTeacher(); if (supabase) return cloudMutation(supabase.from('assignments').insert({ ...assignment, teacher_id: profile!.id })); persist(d => ({ ...d, assignments: [...d.assignments, { ...assignment, id: crypto.randomUUID() }] })); },
    async removeAssignment(id) { requireTeacher(); if (supabase) return cloudMutation(supabase.from('assignments').delete().eq('id', id)); persist(d => ({ ...d, assignments: d.assignments.filter(a => a.id !== id) })); },
    async submit(taskId, answer, duration) {
      if (profile?.role !== 'student') throw new Error('Войдите как ученик, чтобы сохранить попытку.');
      if (supabase) { const result = await supabase.rpc('submit_answer', { selected_task: taskId, submitted_answer: answer, elapsed_seconds: duration }); check(result.error); await refresh(); return result.data as { correct: boolean; solution: string }; }
      const task = data.tasks.find(t => t.id === taskId && t.published); if (!task) throw new Error('Задача недоступна.');
      const correct = answer.trim().toLowerCase() === task.answer?.trim().toLowerCase();
      persist(d => ({ ...d, attempts: [...d.attempts, { id: crypto.randomUUID(), student_id: profile.id, task_id: taskId, answer, correct, duration, created_at: new Date().toISOString() }] }));
      return { correct, solution: task.solution || '' };
    },
    async markSlide(module, slide) {
      if (profile?.role !== 'student') throw new Error('Для сохранения теории войдите как ученик.');
      if (supabase) return cloudMutation(supabase.from('slides').upsert({ student_id: profile.id, module, slide }, { onConflict: 'student_id,module,slide' }));
      persist(d => ({ ...d, slides: d.slides.some(s => s.student_id === profile.id && s.module === module && s.slide === slide) ? d.slides : [...d.slides, { student_id: profile.id, module, slide }] }));
    },
  };
  return <Context.Provider value={value}>{children}</Context.Provider>;
}
export function usePlatform() { const value = useContext(Context); if (!value) throw new Error('PlatformProvider missing'); return value; }
