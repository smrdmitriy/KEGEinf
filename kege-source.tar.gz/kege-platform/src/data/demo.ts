import type { Data } from '../lib/types';
export const demoStudent = { id: 'local-student', name: 'Мой профиль', email: 'student@example.test', role: 'student' as const, group_id: null };
export const demoTeacher = { id: 'local-teacher', name: 'Преподаватель', email: 'teacher@example.test', role: 'teacher' as const };
export const initialData: Data = {
  students: [demoStudent], groups: [], attempts: [], assignments: [], slides: [],
  tasks: [
    { id: 'sample-5-1', module: 5, title: 'Двоичная запись', statement: 'Алгоритм получает натуральное число N. К его двоичной записи справа дописывается 0. Полученная запись переводится в десятичную систему. Какое число получится при N = 13?', answer: '26', solution: '13 = 1101₂. Дописываем 0: 11010₂ = 26. Дописывание нуля справа умножает число на 2.', difficulty: 'Базовый', hint: 'Сдвиг двоичной записи на один разряд влево умножает число на 2.', published: true, teacher_id: null },
    { id: 'sample-5-2', module: 5, title: 'Бит чётности', statement: 'К двоичной записи натурального N справа дописывается остаток от деления количества единиц в записи на 2. Какой результат получится для N = 11?', answer: '23', solution: '11 = 1011₂. Единиц три; 3 mod 2 = 1. Дописываем 1: 10111₂ = 23.', difficulty: 'Базовый', hint: 'Сначала посчитай единицы в двоичной записи числа 11.', published: true, teacher_id: null },
    { id: 'sample-5-3', module: 5, title: 'Найди минимальное N', statement: 'К двоичной записи натурального N справа дописывается 1. Найди минимальное N, для которого полученное число R больше 35.', answer: '18', solution: 'R = 2N + 1. Из 2N + 1 > 35 получаем N > 17. Минимальное натуральное N = 18.', difficulty: 'Средний', hint: 'Вырази R через N: что меняет дописанная справа единица?', published: true, teacher_id: null },
  ],
};
