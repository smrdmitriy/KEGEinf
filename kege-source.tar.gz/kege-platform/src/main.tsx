import React from 'react';
import ReactDOM from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import App from './App';
import { PlatformProvider } from './context/Platform';
import './styles.css';
import './light.css';
ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><PlatformProvider><HashRouter><App /></HashRouter></PlatformProvider></React.StrictMode>);
