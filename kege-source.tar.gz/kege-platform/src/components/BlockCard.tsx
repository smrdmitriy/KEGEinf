import {ArrowUpRight} from 'lucide-react';
import {ModuleIcon} from './ModuleIcon';
import {modules} from '../data/modules';
export type CatalogBlock={id:string;name:string;standard_number:number|null;can_open?:boolean};
export function BlockCard({block,status}:{block:CatalogBlock;status?:string}){
 const standard=modules.find(m=>m.id===block.standard_number);
 return <><div className="card-top"><span className="number">{block.standard_number?String(block.standard_number).padStart(2,'0'):'Блок'}</span><span className="card-icon"><ModuleIcon name={standard?.icon||'BookOpen'}/></span></div><h3>{block.name}</h3><p>{standard?.description||'Теория, классная и домашняя работа'}</p><div className="card-bottom"><span>{status||'Открыть блок'}</span><ArrowUpRight size={17}/></div></>;
}
