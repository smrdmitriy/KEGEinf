import {useEffect,useState} from 'react';
import {supabase} from '../lib/supabase';
import {usePlatform} from '../context/Platform';
export function TeacherTaskAnswer({taskId}:{taskId:string}){
 const {profile,data}=usePlatform();
 const [answer,setAnswer]=useState('');
 const [error,setError]=useState('');
 useEffect(()=>{
  let alive=true;
  if(profile?.role==='teacher'&&supabase)void supabase.rpc('teacher_task_answer',{selected_task:taskId}).then(result=>{if(alive){setAnswer(result.data||'');setError(result.error?'Не удалось загрузить ответ':'');}});
  return()=>{alive=false;};
 },[profile?.id,taskId,data.tasks]);
 if(profile?.role!=='teacher')return null;
 return <p className="teacher-answer"><strong>Правильный ответ</strong> {error||answer||'Загрузка…'}</p>;
}
