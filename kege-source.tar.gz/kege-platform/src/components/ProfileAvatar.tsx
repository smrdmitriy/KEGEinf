import {Star} from 'lucide-react';
import {usePlatform} from '../context/Platform';
export function ProfileAvatar({id,name,avatar,preview=false}:{id:string;name:string;avatar?:string;preview?:boolean}){
 const {data}=usePlatform();const count=new Set(data.attempts.filter(a=>a.student_id===id&&a.correct).map(a=>a.task_id)).size;
 return <div className={`avatar-wrap ${preview?'avatar-preview':''}`}><div className="profile-avatar">{avatar?<img src={avatar} alt="Аватар"/>:name.charAt(0).toUpperCase()}</div>{count>=100&&<span className="achievement-star" title="Решено 100 уникальных задач" aria-label="Награда за 100 решённых задач"><Star fill="currentColor"/><b>100</b></span>}</div>;
}
