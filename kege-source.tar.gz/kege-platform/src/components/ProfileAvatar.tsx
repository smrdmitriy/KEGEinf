import {useEffect,useRef,useState} from 'react';
import {createPortal} from 'react-dom';
import {Star,X} from 'lucide-react';
import {usePlatform} from '../context/Platform';
export function ProfileAvatar({id,name,avatar,preview=false}:{id:string;name:string;avatar?:string;preview?:boolean}){
 const {data}=usePlatform();const count=new Set(data.attempts.filter(a=>a.student_id===id&&a.correct).map(a=>a.task_id)).size;
 const [open,setOpen]=useState(false);const dialog=useRef<HTMLDialogElement>(null);
 useEffect(()=>{if(!open||!dialog.current)return;const element=dialog.current;const previous=document.body.style.overflow;document.body.style.overflow='hidden';element.showModal();return()=>{if(element.open)element.close();document.body.style.overflow=previous;};},[open]);
 const initial=name.charAt(0).toUpperCase();
 return <><div className={`avatar-wrap ${preview?'avatar-preview':''}`}><button type="button" className="profile-avatar avatar-zoom-trigger" aria-label={`Увеличить аватар: ${name}`} aria-haspopup="dialog" onClick={()=>setOpen(true)}>{avatar?<img src={avatar} alt={`Аватар ${name}`}/>:initial}</button>{count>=100&&<span className="achievement-star" title="Решено 100 уникальных задач" aria-label="Награда за 100 решённых задач"><Star fill="currentColor"/><b>100</b></span>}</div>{open&&createPortal(<dialog ref={dialog} className="avatar-lightbox" aria-label={`Аватар: ${name}`} onClose={()=>setOpen(false)} onClick={event=>{if(event.target===event.currentTarget)dialog.current?.close();}}><div className="avatar-lightbox-content"><button type="button" className="avatar-lightbox-close" aria-label="Закрыть аватар" onClick={()=>dialog.current?.close()}><X size={24}/></button>{avatar?<img className="avatar-full-image" src={avatar} alt={`Аватар ${name}`}/>:<div className="avatar-full-initial">{initial}</div>}<p>{name}</p></div></dialog>,document.body)}</>;
}
