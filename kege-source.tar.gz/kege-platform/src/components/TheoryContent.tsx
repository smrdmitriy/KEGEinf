import {useEffect,useState} from 'react';
import {supabase} from '../lib/supabase';
function TheoryImage({id,blockId}:{id:string;blockId:string}){
 const [source,setSource]=useState(''),[alt,setAlt]=useState('Иллюстрация к теории'),[error,setError]=useState('');
 useEffect(()=>{let alive=true;let url='';setSource('');setError('');async function load(){if(!supabase)throw Error('База не подключена');const r=await supabase.from('theory_images').select('object_path,alt').eq('id',id).eq('block_id',blockId).maybeSingle();if(r.error||!r.data)throw Error('Изображение недоступно');const image=await supabase.storage.from('theory-images').download(r.data.object_path);if(image.error||!image.data)throw Error('Не удалось загрузить изображение');if(alive){url=URL.createObjectURL(image.data);setSource(url);setAlt(r.data.alt||'Иллюстрация к теории');}}void load().catch(e=>{if(alive)setError(e.message);});return()=>{alive=false;if(url)URL.revokeObjectURL(url);};},[id,blockId]);
 return source?<img className="theory-image" src={source} alt={alt} loading="lazy"/>:<p className="muted" role="status">{error||'Загрузка изображения…'}</p>;
}
export function TheoryContent({text,blockId}:{text:string;blockId:string}){return <div className="theory-content">{text.split(/(\[\[image:[0-9a-f-]{36}\]\])/i).map((part,index)=>{const match=part.match(/^\[\[image:([0-9a-f-]{36})\]\]$/i);return match?<TheoryImage key={`${index}:${part}`} id={match[1]} blockId={blockId}/>:part?<div className="task-statement" key={index}>{part}</div>:null;})}</div>;}
