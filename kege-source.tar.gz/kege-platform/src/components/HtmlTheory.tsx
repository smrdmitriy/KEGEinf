import {useEffect,useMemo,useRef,useState} from 'react';
import {Maximize2,Minimize2} from 'lucide-react';
import {isolatedTheoryDocument} from '../lib/htmlTheory';
export function HtmlTheory({html}:{html:string}){
 const source=useMemo(()=>isolatedTheoryDocument(html),[html]);const [message,setMessage]=useState(''),[fullscreen,setFullscreen]=useState(false);const container=useRef<HTMLDivElement>(null);
 useEffect(()=>{const update=()=>setFullscreen(document.fullscreenElement===container.current);document.addEventListener('fullscreenchange',update);return()=>document.removeEventListener('fullscreenchange',update);},[]);
 const label=fullscreen?'Выйти из полноэкранного режима':'На весь экран';
 return <div className="html-theory" ref={container}><button type="button" className="interactive-fullscreen" aria-label={label} title={label} onClick={async()=>{try{setMessage('');if(document.fullscreenElement===container.current)await document.exitFullscreen();else if(container.current?.requestFullscreen)await container.current.requestFullscreen();else setMessage('Полноэкранный режим недоступен в этом браузере');}catch{setMessage('Полноэкранный режим недоступен в этом браузере');}}}>{fullscreen?<Minimize2 size={21}/>:<Maximize2 size={21}/>}</button>{message&&<p className="interactive-message" role="status">{message}</p>}<iframe title="Интерактивная теория" sandbox="allow-scripts" referrerPolicy="no-referrer" srcDoc={source} className="html-theory-frame"/></div>;
}
