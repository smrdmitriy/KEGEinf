import {useMemo,useRef,useState} from 'react';
import {isolatedTheoryDocument} from '../lib/htmlTheory';
export function HtmlTheory({html}:{html:string}){
 const source=useMemo(()=>isolatedTheoryDocument(html),[html]);const [restart,setRestart]=useState(0),[message,setMessage]=useState('');const container=useRef<HTMLDivElement>(null);
 return <div className="html-theory" ref={container}><div className="form-actions"><button type="button" className="button secondary" onClick={()=>setRestart(restart+1)}>Перезапустить интерактив</button><button type="button" className="button secondary" onClick={async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else if(container.current?.requestFullscreen)await container.current.requestFullscreen();else setMessage('Полноэкранный режим недоступен в этом браузере');}catch{setMessage('Полноэкранный режим недоступен в этом браузере');}}}>На весь экран</button></div>{message&&<p role="status">{message}</p>}<iframe key={restart} title="Интерактивная теория" sandbox="allow-scripts" referrerPolicy="no-referrer" srcDoc={source} className="html-theory-frame"/></div>;
}
