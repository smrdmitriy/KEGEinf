import { Network, Table2, Database, Binary, Workflow, Pentagon, Image, Boxes, Sheet, Search, HardDrive, Replace, Globe, Braces, GitBranch, ListOrdered, Route, Flag, Cpu, Terminal, TextCursorInput, Hash, ArrowDownWideNarrow, ChartNoAxesCombined, Code2, type LucideIcon } from 'lucide-react';
const icons: Record<string, LucideIcon> = { Network, Table2, Database, Binary, Workflow, Pentagon, Image, Boxes, Sheet, Search, HardDrive, Replace, Globe, Braces, GitBranch, ListOrdered, Route, Flag, Cpu, Terminal, TextCursorInput, Hash, ArrowDownWideNarrow, ChartNoAxesCombined };
export function ModuleIcon({ name, size = 20 }: { name: string; size?: number }) {
  const Icon = icons[name] || Code2;
  return <Icon size={size} strokeWidth={1.6} aria-hidden="true" />;
}
