import type {Data} from '../lib/types';
import {usePlatform} from '../context/Platform';
export function reviewClass(data:Data,taskId:string,studentId?:string){
 const attempts=data.attempts.filter(a=>a.task_id===taskId&&(!studentId||a.student_id===studentId));
 const latest=new Map<string,typeof attempts[number]>();
 for(const attempt of attempts){const previous=latest.get(attempt.student_id);if(!previous||previous.created_at<attempt.created_at)latest.set(attempt.student_id,attempt);}
 if([...latest.values()].some(a=>!a.correct))return 'task-incorrect';
 const works=data.homework.filter(h=>h.task_id===taskId&&(!studentId||h.student_id===studentId)&&(h.code.trim()||h.image));
 if(!works.length||[...latest.keys()].some(id=>!works.some(h=>h.student_id===id)))return 'task-missing-solution';
 return '';
}
export function TaskReviewState({taskId}:{taskId:string}){
 const {data}=usePlatform();const ids=[...new Set([...data.attempts.filter(a=>a.task_id===taskId).map(a=>a.student_id),...data.homework.filter(h=>h.task_id===taskId).map(h=>h.student_id)])];
 return <details className="import-panel"><summary>Ответы и решения учеников · {ids.length}</summary>{!ids.length&&<p>Прикреплённых решений пока нет.</p>}{ids.map(id=>{const latest=data.attempts.filter(a=>a.task_id===taskId&&a.student_id===id).sort((a,b)=>b.created_at.localeCompare(a.created_at))[0];const works=data.homework.filter(h=>h.task_id===taskId&&h.student_id===id);return <div className={`task-review-row ${reviewClass(data,taskId,id)}`} key={id}><strong>{data.students.find(s=>s.id===id)?.name||'Ученик'}</strong><p>{latest?`${latest.correct?'Верный':'Неверный'} ответ · ${latest.answer}`:'Ответ ещё не проверен'} · {works.length?'Решение прикреплено':'Нет прикреплённого решения'}</p>{works.map(h=><details key={h.id}><summary>Решение · {new Date(h.created_at).toLocaleString('ru')}</summary>{h.code&&<pre className="homework-code">{h.code}</pre>}{h.image&&<img className="homework-image" src={h.image} alt="Решение ученика"/>}</details>)}</div>;})}</details>;
}
