import {useEffect,useState} from 'react';
import {usePlatform} from '../context/Platform';
import {supabase} from '../lib/supabase';
import {groupStudentSolutions} from '../lib/groupStudentSolutions';
import {HomeworkBody,HomeworkFeedback} from './LearningBlocks';
export function StudentSolutions({studentId}:{studentId:string}){
 const {data}=usePlatform();const [blocks,setBlocks]=useState<{id:string;name:string;standard_number:number|null}[]>([]),[error,setError]=useState(''),[loading,setLoading]=useState(true);
 useEffect(()=>{let alive=true;async function load(){if(!supabase)throw Error('База не подключена');const r=await supabase.from('task_folders').select('id,name,standard_number');if(r.error)throw Error('Не удалось загрузить блоки');if(alive){setBlocks(r.data||[]);setError('');}}void load().catch(e=>{if(alive)setError(e.message);}).finally(()=>{if(alive)setLoading(false);});return()=>{alive=false;};},[studentId,data.tasks]);
 const groups=groupStudentSolutions(data.homework,data.tasks,blocks,studentId);
 return <section className="panel"><h2>Все отправленные решения</h2>{loading&&<p>Загрузка блоков…</p>}{error&&<p className="alert" role="alert">{error}</p>}{!loading&&!error&&groups.map(block=><details className="import-panel homework-block" key={block.id}><summary>{block.name} · Задач: {block.tasks.length}</summary>{block.tasks.map(task=><details className="import-panel" key={task.id}><summary>{task.title} · Решений: {task.works.length}</summary>{task.works.map(work=><article className="homework-submission" key={work.id}><h3>{{pending:'На проверке',accepted:'Принято',revision:'На доработке'}[work.status]} · {new Date(work.created_at).toLocaleString('ru-RU')}</h3><HomeworkBody work={work}/><HomeworkFeedback work={work}/></article>)}</details>)}</details>)}{!loading&&!error&&!groups.length&&<p>Работ пока нет.</p>}</section>;
}
