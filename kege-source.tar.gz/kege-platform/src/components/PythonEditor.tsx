import {useRef,type KeyboardEvent} from 'react';
const tokenPattern=/(#[^\n]*|"""[\s\S]*?"""|'''[\s\S]*?'''|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\b(?:False|None|True|and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield)\b|\b\d+(?:\.\d+)?\b)/g;
export function PythonEditor({value,onChange}:{value:string;onChange:(value:string)=>void}){
 const input=useRef<HTMLTextAreaElement>(null);const highlight=useRef<HTMLPreElement>(null);
 function keydown(event:KeyboardEvent<HTMLTextAreaElement>){
  if(event.key!=='Tab'&&event.key!=='Enter')return;
  event.preventDefault();const field=event.currentTarget;const start=field.selectionStart,end=field.selectionEnd;
  const line=value.slice(0,start).split('\n').at(-1)||'';
  const indentation=line.match(/^\s*/)?.[0]||'';
  const insert=event.key==='Tab'?'    ':'\n'+indentation+(line.trimEnd().endsWith(':')?'    ':'');
  if(value.length+insert.length-(end-start)>50000)return;
  onChange(value.slice(0,start)+insert+value.slice(end));
  requestAnimationFrame(()=>{field.selectionStart=field.selectionEnd=start+insert.length;});
 }
 return <div className="python-editor"><div className="python-editor-title">Python · отступ 4 пробела</div><div className="python-editor-content"><pre ref={highlight} aria-hidden="true">{value.split(tokenPattern).map((token,i)=><span key={i} className={token.startsWith('#')?'py-comment':/^["']/.test(token)?'py-string':/^\d/.test(token)?'py-number':/^(False|None|True|and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield)$/.test(token)?'py-keyword':''}>{token}</span>)}{'\n'}</pre><textarea ref={input} aria-label="Код решения Python" value={value} maxLength={50000} wrap="off" spellCheck={false} autoCapitalize="off" autoCorrect="off" onKeyDown={keydown} onChange={e=>onChange(e.target.value)} onScroll={e=>{if(highlight.current)highlight.current.style.transform=`translate(${-e.currentTarget.scrollLeft}px,${-e.currentTarget.scrollTop}px)`;}}/></div></div>;
}
