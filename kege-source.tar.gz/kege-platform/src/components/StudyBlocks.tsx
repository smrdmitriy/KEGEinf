import {TheoryEditor} from './TheoryEditor';
import {TheoryContent} from './TheoryContent';
import {TaskFiles} from './TaskFiles';
import {BlockAssignments} from './BlockAssignments';
import {reviewClass,TaskReviewState} from './TaskReviewState';
import {TeacherTaskAnswer} from './TeacherTaskAnswer';
import {useEffect,useState,type FormEvent} from 'react';
import {supabase} from '../lib/supabase';
import {usePlatform} from '../context/Platform';
import {ModuleIcon} from './ModuleIcon';
import {BlockCard} from './BlockCard';
import {TaskCard} from '../pages/Module';
import {BulkImport} from './LearningBlocks';
import type {Task} from '../lib/types';

type Block={id:string;name:string;theory:string;theory_format:'text'|'html';theory_html:string;module:number|null;standard_number:number|null;description:string;icon:string};
export function StudyBlocks({teacher=false,initialId=''}:{teacher?:boolean;initialId?:string}){
 const p=usePlatform();
 const [blocks,setBlocks]=useState<Block[]>([]);
 const [selected,setSelected]=useState(initialId);
 const [tab,setTab]=useState<'theory'|'classwork'|'homework'>('theory');
 const [showCreate,setShowCreate]=useState(false);
 const [name,setName]=useState('');
 const [description,setDescription]=useState('');
 const [icon,setIcon]=useState('Network');
 const [showIcons,setShowIcons]=useState(false);
 const [deleting,setDeleting]=useState<Block|null>(null);
 const iconOptions=[["Network", "Граф"], ["Table2", "Таблица"], ["Database", "База данных"], ["Binary", "Двоичный код"], ["Workflow", "Алгоритм"], ["Pentagon", "Геометрия"], ["Image", "Изображение"], ["Boxes", "Комбинаторика"], ["Sheet", "Табличные данные"], ["Search", "Поиск"], ["HardDrive", "Носитель данных"], ["Replace", "Преобразование"], ["Globe", "Сети"], ["Braces", "Логика"], ["GitBranch", "Рекурсия"], ["ListOrdered", "Последовательность"], ["Route", "Маршруты"], ["Flag", "Стратегия"], ["Cpu", "Процессор"], ["Terminal", "Программирование"], ["TextCursorInput", "Строки"], ["Hash", "Числа"], ["ArrowDownWideNarrow", "Сортировка"], ["ChartNoAxesCombined", "Анализ данных"]];
 const [editor,setEditor]=useState<Task|null>(null);
 const [busy,setBusy]=useState(false);
 const [message,setMessage]=useState('');
 const block=blocks.find(b=>b.id===selected);
 async function load(){
  if(!supabase)return;
  if(teacher){const setup=await supabase.rpc('ensure_standard_blocks');if(setup.error)throw Error(setup.error.message);}
  const r=await supabase.from('task_folders').select('id,name,theory,theory_format,theory_html,module,standard_number,description,icon');
  if(r.error)throw Error(r.error.message);
  const standard=(b:Block)=>b.standard_number!==null;
  setBlocks((r.data||[]).sort((a,b)=>standard(a)&&standard(b)?a.standard_number!-b.standard_number!:standard(a)?-1:standard(b)?1:a.name.localeCompare(b.name,'ru')));
 }
 useEffect(()=>{if(p.profile)void load().catch(e=>setMessage(e.message));},[p.profile?.id,p.data.tasks]);
 async function run(action:()=>Promise<void>,success:string){setBusy(true);setMessage('');try{await action();setMessage(success);}catch(e){setMessage((e as Error).message);}finally{setBusy(false);}}
 async function create(e:FormEvent){e.preventDefault();await run(async()=>{if(!supabase)return;const r=await supabase.from('task_folders').insert({name:name.trim(),description:description.trim(),icon,teacher_id:p.profile!.id,module:null,work_type:'classwork'}).select('id,name,theory,theory_format,theory_html,module,standard_number,description,icon').single();if(r.error)throw Error(r.error.message);setBlocks(current=>[...current,r.data]);setSelected(r.data.id);setName('');setDescription('');setIcon('Network');setShowIcons(false);setShowCreate(false);setTab('theory');},'Блок создан');}
 function newTask(){setEditor({id:crypto.randomUUID(),folder_id:selected,module:1,work_type:tab==='homework'?'homework':'classwork',title:'',statement:'',answer:'',solution:'',hint:'',difficulty:'Базовый',published:true,teacher_id:p.profile!.id});}
 if(!p.profile||(!teacher&&p.profile.role==='teacher'))return null;
 return <section className="panel study-blocks"><div className="panel-heading"><h1>{block?block.name:teacher?'Банк задач':'Мои учебные блоки'}</h1>{block&&<button className="button secondary" onClick={()=>{setSelected('');setEditor(null);setMessage('');}}>← Все блоки</button>}</div>
 {message&&<p className="alert" role="status">{message}</p>}
 {!block?<>{teacher&&!showCreate&&<button className="button primary" onClick={()=>setShowCreate(true)}>Добавить блок</button>}{teacher&&showCreate&&<form className="block-create-form" onSubmit={create}><label>Название блока<input required maxLength={100} value={name} onChange={e=>setName(e.target.value)} placeholder="Например, Алгоритмы и исполнители"/></label><label>Описание<textarea required maxLength={300} rows={3} value={description} onChange={e=>setDescription(e.target.value)} placeholder="Что ученики изучат в этом блоке"/></label><div className="icon-selector"><span>Пиктограмма</span><button type="button" className="button secondary" aria-expanded={showIcons} aria-controls="block-icons" onClick={()=>setShowIcons(!showIcons)}><ModuleIcon name={icon} size={28}/>Выбрать пиктограмму</button>{showIcons&&<div className="icon-grid" id="block-icons">{iconOptions.map(([value,label])=><button type="button" key={value} className={icon===value?'selected':''} aria-label={label} title={label} aria-pressed={icon===value} onClick={()=>{setIcon(value);setShowIcons(false);}}><ModuleIcon name={value} size={30}/></button>)}</div>}</div><div className="block-card-preview"><span className="muted">Предпросмотр карточки</span><div className="module-card"><BlockCard block={{id:'preview',name:name||'Название блока',standard_number:null,description:description||'Описание блока',icon}}/></div></div><div className="form-actions"><button className="button primary" disabled={busy}>Создать блок</button><button type="button" className="button secondary" disabled={busy} onClick={()=>setShowCreate(false)}>Отмена</button></div></form>}<div className="module-grid">{blocks.map(b=><button key={b.id} className="module-card" onClick={()=>{setSelected(b.id);setTab('theory');setMessage('');}}><BlockCard block={b} status={`${p.data.tasks.filter(t=>t.folder_id===b.id).length} задач · Открыть блок`}/></button>)}</div>{!blocks.length&&<p>Учебных блоков пока нет.</p>}</>:<>
 {teacher&&block.standard_number===null&&<button className="button danger-button" disabled={busy} onClick={()=>setDeleting(block)}>Удалить блок</button>}
 {teacher&&<BlockAssignments key={selected} blockId={selected}/>}
 <div className="form-actions block-tabs" role="tablist">{(['theory','classwork','homework'] as const).map(kind=><button key={kind} role="tab" aria-selected={tab===kind} className={`button ${tab===kind?'primary':'secondary'}`} onClick={()=>{setTab(kind);setEditor(null);}}>{{theory:'Теория',classwork:'Классная работа',homework:'Домашняя работа'}[kind]}</button>)}</div>
 {tab==='theory'?(teacher?<TheoryEditor key={block.id} block={block} onSaved={load}/>:<TheoryContent text={block.theory||'Преподаватель пока не добавил теорию.'} blockId={block.id} html={block.theory_html} format={block.theory_format}/>):<>
 {teacher&&<><button className="button primary" onClick={newTask}>Добавить {tab==='homework'?'домашнюю':'классную'} работу</button><BulkImport key={`${selected}-${tab}`} module={1} workType={tab} folderId={selected}/></>}
 {editor&&<form className="panel credentials-panel" onSubmit={e=>{e.preventDefault();void run(async()=>{await p.saveTask(editor);setEditor({...editor,answer:'',solution:''});},'Задача сохранена. Можно прикрепить файлы ниже.');}}><label>Название<input required maxLength={150} value={editor.title} onChange={e=>setEditor({...editor,title:e.target.value})}/></label><label>Условие<textarea required maxLength={20000} rows={6} value={editor.statement} onChange={e=>setEditor({...editor,statement:e.target.value})}/></label><TaskFiles taskId={editor.id} editable/><label>Ответ<input required={!p.data.tasks.some(t=>t.id===editor.id)} placeholder="Оставьте пустым для сохранения прежнего ответа" value={editor.answer||''} onChange={e=>setEditor({...editor,answer:e.target.value})}/></label><label>Решение<textarea rows={4} value={editor.solution||''} onChange={e=>setEditor({...editor,solution:e.target.value})}/></label><label>Подсказка<textarea value={editor.hint} onChange={e=>setEditor({...editor,hint:e.target.value})}/></label><label>Сложность<select value={editor.difficulty} onChange={e=>setEditor({...editor,difficulty:e.target.value})}>{['Базовый','Средний','Высокий'].map(v=><option key={v}>{v}</option>)}</select></label><label className="checkbox-label"><input type="checkbox" checked={editor.published} onChange={e=>setEditor({...editor,published:e.target.checked})}/>Опубликовано</label><div className="form-actions"><button disabled={busy} className="button primary">Сохранить</button><button type="button" className="button secondary" onClick={()=>setEditor(null)}>Отмена</button></div></form>}
 {p.data.tasks.filter(t=>t.folder_id===selected&&(t.work_type||'classwork')===tab).map(t=><div key={t.id}>{teacher?<article className={`task-bank-card ${reviewClass(p.data,t.id)}`}><h3>{t.title}</h3><p>{t.published?'Опубликовано':'Черновик'}</p><p className="task-statement">{t.statement}</p><TaskFiles taskId={t.id}/>{t.images?.map(src=><img key={src} className="task-illustration" src={import.meta.env.BASE_URL+src} alt="Схема к задаче"/>)}<div className="form-actions"><button className="button secondary" onClick={()=>setEditor({...t,answer:'',solution:''})}>Редактировать</button><button className="button secondary" disabled={busy} onClick={()=>void run(()=>p.saveTask({...t,published:!t.published}),'Статус обновлён')}>{t.published?'Скрыть':'Опубликовать'}</button><label>Переместить в<select value="" onChange={e=>{const [destination,kind]=e.target.value.split(':');if(destination)void run(async()=>{if(!supabase)return;const r=await supabase.rpc('move_task',{selected_task:t.id,selected_folder:destination,selected_module:t.module,selected_work_type:kind});if(r.error)throw Error(r.error.message);await p.refresh();},'Задача перемещена');}}><option value="">Выберите блок и работу</option>{blocks.map(b=><optgroup key={b.id} label={b.name}><option value={`${b.id}:classwork`}>Классная работа</option><option value={`${b.id}:homework`}>Домашняя работа</option></optgroup>)}</select></label><button className="button danger-button" disabled={busy} onClick={()=>{if(window.confirm(`Удалить задачу «${t.title}» и её попытки навсегда?`))void run(()=>p.removeTask(t.id),'Задача удалена');}}>Удалить</button></div><TeacherTaskAnswer taskId={t.id}/><TaskReviewState taskId={t.id}/></article>:<TaskCard task={t}/>}</div>)}
 </>}
 </>}
 {deleting&&<div className="modal-overlay"><section className="modal small-modal glass" role="alertdialog" aria-modal="true" aria-labelledby="delete-block-title"><h2 id="delete-block-title">Удалить блок «{deleting.name}»?</h2><p>Будут безвозвратно удалены теория, задачи блока, связанные попытки, решения и назначения ученикам.</p><div className="form-actions"><button autoFocus className="button secondary" disabled={busy} onClick={()=>setDeleting(null)}>Отмена</button><button className="button danger-button" disabled={busy} onClick={()=>void run(async()=>{if(!supabase)throw Error('База не подключена');const result=await supabase.rpc('delete_study_block',{selected_block:deleting.id});if(result.error)throw Error(result.error.message);setBlocks(current=>current.filter(b=>b.id!==deleting.id));setSelected('');setEditor(null);setDeleting(null);await p.refresh();},'Блок удалён')}>{busy?'Удаляем…':'Удалить навсегда'}</button></div></section></div>}
 </section>;
}
