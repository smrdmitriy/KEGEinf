import {useEffect,useState,type FormEvent} from 'react';
import {supabase} from '../lib/supabase';
import {usePlatform} from '../context/Platform';
import {BlockCard} from './BlockCard';
import {TaskCard} from '../pages/Module';
import {BulkImport} from './LearningBlocks';
import type {Task} from '../lib/types';

type Block={id:string;name:string;theory:string;module:number|null;standard_number:number|null};
export function StudyBlocks({teacher=false,initialId=''}:{teacher?:boolean;initialId?:string}){
 const p=usePlatform();
 const [blocks,setBlocks]=useState<Block[]>([]);
 const [selected,setSelected]=useState(initialId);
 const [tab,setTab]=useState<'theory'|'classwork'|'homework'>('theory');
 const [name,setName]=useState('');
 const [theory,setTheory]=useState('');
 const [editor,setEditor]=useState<Task|null>(null);
 const [busy,setBusy]=useState(false);
 const [message,setMessage]=useState('');
 const block=blocks.find(b=>b.id===selected);
 async function load(){
  if(!supabase)return;
  if(teacher){const setup=await supabase.rpc('ensure_standard_blocks');if(setup.error)throw Error(setup.error.message);}
  const r=await supabase.from('task_folders').select('id,name,theory,module,standard_number');
  if(r.error)throw Error(r.error.message);
  const standard=(b:Block)=>b.standard_number!==null;
  setBlocks((r.data||[]).sort((a,b)=>standard(a)&&standard(b)?a.standard_number!-b.standard_number!:standard(a)?-1:standard(b)?1:a.name.localeCompare(b.name,'ru')));
 }
 useEffect(()=>{if(p.profile)void load().catch(e=>setMessage(e.message));},[p.profile?.id,p.data.tasks]);
 async function run(action:()=>Promise<void>,success:string){setBusy(true);setMessage('');try{await action();setMessage(success);}catch(e){setMessage((e as Error).message);}finally{setBusy(false);}}
 async function create(e:FormEvent){e.preventDefault();await run(async()=>{if(!supabase)return;const r=await supabase.from('task_folders').insert({name:name.trim(),teacher_id:p.profile!.id,module:null,work_type:'classwork'}).select('id,name,theory,module,standard_number').single();if(r.error)throw Error(r.error.message);setBlocks(current=>[...current,r.data]);setSelected(r.data.id);setTheory('');setName('');setTab('theory');},'Блок создан');}
 function newTask(){setEditor({id:crypto.randomUUID(),folder_id:selected,module:1,work_type:tab==='homework'?'homework':'classwork',title:'',statement:'',answer:'',solution:'',hint:'',difficulty:'Базовый',published:true,teacher_id:p.profile!.id});}
 if(!p.profile||(!teacher&&p.profile.role==='teacher'))return null;
 return <section className="panel study-blocks"><div className="panel-heading"><h1>{block?block.name:teacher?'Банк задач':'Мои учебные блоки'}</h1>{block&&<button className="button secondary" onClick={()=>{setSelected('');setEditor(null);setMessage('');}}>← Все блоки</button>}</div>
 {message&&<p className="alert" role="status">{message}</p>}
 {!block?<>{teacher&&<form className="inline-form" onSubmit={create}><label>Название блока<input required maxLength={100} value={name} onChange={e=>setName(e.target.value)} placeholder="Например, Алгоритмы и исполнители"/></label><button className="button primary" disabled={busy}>Добавить блок</button></form>}<div className="module-grid">{blocks.map(b=><button key={b.id} className="module-card" onClick={()=>{setSelected(b.id);setTheory(b.theory);setTab('theory');setMessage('');}}><BlockCard block={b} status={`${p.data.tasks.filter(t=>t.folder_id===b.id).length} задач · Открыть блок`}/></button>)}</div>{!blocks.length&&<p>Учебных блоков пока нет.</p>}</>:<>
 {teacher&&<details className="import-panel"><summary>Назначить блок ученикам</summary><form className="inline-form" onSubmit={e=>{e.preventDefault();const value=String(new FormData(e.currentTarget).get('recipient'));const [kind,...rest]=value.split(':');const id=rest.join(':');void run(async()=>{if(!supabase)return;const r=await supabase.rpc('assign_study_block',{selected_block:selected,selected_student:kind==='student'?id:null,school_class:kind==='class'?id:null,selected_group:kind==='group'?id:null});if(r.error)throw Error(r.error.message);},'Блок назначен. Теория, классная и домашняя работа доступны ученикам.');}}><label>Получатель<select name="recipient" required><option value="">Выберите ученика, класс или группу</option>{[...new Set(p.data.students.map(s=>s.school_class).filter(Boolean))].sort().map(c=><option key={c} value={`class:${c}`}>Класс {c}</option>)}{p.data.groups.map(g=><option key={g.id} value={`group:${g.id}`}>Группа {g.name}</option>)}{p.data.students.map(s=><option key={s.id} value={`student:${s.id}`}>{s.name}</option>)}</select></label><button className="button primary" disabled={busy}>Назначить блок</button></form></details>}
 <div className="form-actions block-tabs" role="tablist">{(['theory','classwork','homework'] as const).map(kind=><button key={kind} role="tab" aria-selected={tab===kind} className={`button ${tab===kind?'primary':'secondary'}`} onClick={()=>{setTab(kind);setEditor(null);}}>{{theory:'Теория',classwork:'Классная работа',homework:'Домашняя работа'}[kind]}</button>)}</div>
 {tab==='theory'?(teacher?<form className="credentials-panel" onSubmit={e=>{e.preventDefault();void run(async()=>{if(!supabase)return;const r=await supabase.from('task_folders').update({theory}).eq('id',selected);if(r.error)throw Error(r.error.message);await load();},'Теория сохранена');}}><label>Теория блока<textarea rows={14} maxLength={100000} value={theory} onChange={e=>setTheory(e.target.value)}/></label><button className="button primary" disabled={busy}>Сохранить теорию</button></form>:<div className="task-statement">{block.theory||'Преподаватель пока не добавил теорию.'}</div>):<>
 {teacher&&<><button className="button primary" onClick={newTask}>Добавить {tab==='homework'?'домашнюю':'классную'} работу</button><BulkImport key={`${selected}-${tab}`} module={1} workType={tab} folderId={selected}/></>}
 {editor&&<form className="panel credentials-panel" onSubmit={e=>{e.preventDefault();void run(async()=>{await p.saveTask(editor);setEditor(null);},'Задача сохранена');}}><label>Название<input required maxLength={150} value={editor.title} onChange={e=>setEditor({...editor,title:e.target.value})}/></label><label>Условие<textarea required maxLength={20000} rows={6} value={editor.statement} onChange={e=>setEditor({...editor,statement:e.target.value})}/></label><label>Ответ<input required={!p.data.tasks.some(t=>t.id===editor.id)} placeholder="Оставьте пустым для сохранения прежнего ответа" value={editor.answer||''} onChange={e=>setEditor({...editor,answer:e.target.value})}/></label><label>Решение<textarea rows={4} value={editor.solution||''} onChange={e=>setEditor({...editor,solution:e.target.value})}/></label><label>Подсказка<textarea value={editor.hint} onChange={e=>setEditor({...editor,hint:e.target.value})}/></label><label>Сложность<select value={editor.difficulty} onChange={e=>setEditor({...editor,difficulty:e.target.value})}>{['Базовый','Средний','Высокий'].map(v=><option key={v}>{v}</option>)}</select></label><label className="checkbox-label"><input type="checkbox" checked={editor.published} onChange={e=>setEditor({...editor,published:e.target.checked})}/>Опубликовано</label><div className="form-actions"><button disabled={busy} className="button primary">Сохранить</button><button type="button" className="button secondary" onClick={()=>setEditor(null)}>Отмена</button></div></form>}
 {p.data.tasks.filter(t=>t.folder_id===selected&&(t.work_type||'classwork')===tab).map(t=><div key={t.id}>{teacher?<article className="task-bank-card"><h3>{t.title}</h3><p>{t.published?'Опубликовано':'Черновик'}</p><p className="task-statement">{t.statement}</p>{t.images?.map(src=><img key={src} className="task-illustration" src={import.meta.env.BASE_URL+src} alt="Схема к задаче"/>)}<div className="form-actions"><button className="button secondary" onClick={()=>setEditor({...t,answer:'',solution:''})}>Редактировать</button><button className="button secondary" disabled={busy} onClick={()=>void run(()=>p.saveTask({...t,published:!t.published}),'Статус обновлён')}>{t.published?'Скрыть':'Опубликовать'}</button><label>Переместить в<select value="" onChange={e=>{const [destination,kind]=e.target.value.split(':');if(destination)void run(async()=>{if(!supabase)return;const r=await supabase.rpc('move_task',{selected_task:t.id,selected_folder:destination,selected_module:t.module,selected_work_type:kind});if(r.error)throw Error(r.error.message);await p.refresh();},'Задача перемещена');}}><option value="">Выберите блок и работу</option>{blocks.map(b=><optgroup key={b.id} label={b.name}><option value={`${b.id}:classwork`}>Классная работа</option><option value={`${b.id}:homework`}>Домашняя работа</option></optgroup>)}</select></label><button className="button danger-button" disabled={busy} onClick={()=>{if(window.confirm(`Удалить задачу «${t.title}» и её попытки навсегда?`))void run(()=>p.removeTask(t.id),'Задача удалена');}}>Удалить</button></div></article>:<TaskCard task={t}/>}</div>)}
 </>}
 </>}
 </section>;
}
