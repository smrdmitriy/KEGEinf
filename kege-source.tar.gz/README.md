# КЕГЭ | Информатика

Образовательная платформа подготовки к ЕГЭ по информатике: React, TypeScript, Vite, Tailwind CSS, Supabase.

Приложение и инструкции: [kege-platform/README.md](kege-platform/README.md).

```sh
cd kege-platform
npm ci
npm run dev
```

Корневой GitHub Actions workflow проверяет и публикует приложение из подпапки `kege-platform`.
